import sys
import os
import shutil
import re
import zipfile
import json
import html
import textwrap
from unidecode import unidecode
from odf.opendocument import load
from odf import text, table, draw, style

# --- CONFIGURATION ---
VERSION = "V331-Footnotes"


# --- UTILITAIRES ---

def load_configuration(config_path):
    default_config = {
        "mkdocs": {
            "site_name": "Documentation",
            "site_url": "",
            "repo_url": "",
            "repo_name": "GitHub"
        },
        "footer": "<footer>Pied de page</footer>",
        "code": {
            "language": "python",
            "style_keywords": ["code", "consolas", "source"],
            "default_language": "text",
            "detection_rules": {}
        },
        "document_title": {
            "style_names": ["Title", "Titre", "Titre principal"],
            "css": "font-size: 28px; font-weight: bold; margin-bottom: 1em;"
        },
        "debug": True,
        "files_to_copy": [],
        "extra": {}
    }

    if not os.path.exists(config_path):
        return default_config

    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            user_config = json.load(f)
            if "mkdocs" in user_config:
                default_config["mkdocs"].update(user_config["mkdocs"])
                # V326: md_in_html requis pour bordures et ancres
                exts = default_config["mkdocs"].get("markdown_extensions", [])
                has_md_in_html = False
                for e in exts:
                    if isinstance(e, str) and e == "md_in_html":
                        has_md_in_html = True
                    elif isinstance(e, dict) and "md_in_html" in e:
                        has_md_in_html = True
                if not has_md_in_html:
                    if isinstance(exts, list):
                        exts.append("md_in_html")
                    else:
                        exts = ["md_in_html"]
                default_config["mkdocs"]["markdown_extensions"] = exts

                # V331: extension 'footnotes' pour notes de bas de page
                exts = default_config["mkdocs"].get("markdown_extensions", [])
                has_footnotes = False
                for e in exts:
                    if isinstance(e, str) and e == "footnotes":
                        has_footnotes = True
                    elif isinstance(e, dict) and "footnotes" in e:
                        has_footnotes = True
                if not has_footnotes:
                    if isinstance(exts, list):
                        exts.append("footnotes")
                    else:
                        exts = ["footnotes"]
                default_config["mkdocs"]["markdown_extensions"] = exts

                if "theme" in user_config["mkdocs"]:
                    default_config["mkdocs"]["theme"] = user_config["mkdocs"]["theme"]

            if "footer" in user_config: default_config["footer"] = user_config["footer"]
            if "code" in user_config: default_config["code"].update(user_config["code"])
            if "document_title" in user_config: default_config["document_title"].update(user_config["document_title"])
            if "debug" in user_config: default_config["debug"] = user_config["debug"]
            if "files_to_copy" in user_config: default_config["files_to_copy"] = user_config["files_to_copy"]
            if "extra" in user_config: default_config["extra"] = user_config["extra"]
            return default_config
    except Exception as e:
        print(f"ERREUR lecture config: {e}. Utilisation des défauts.")
        return default_config


def create_directory(path):
    if not os.path.exists(path):
        os.makedirs(path)


def get_attribute_safe(node, attr_name):
    if hasattr(node, 'attributes'):
        for key, value in node.attributes.items():
            if isinstance(key, tuple):
                if key[1] == attr_name: return value
            elif key == attr_name:
                return value
    return None


def safe_int(val):
    try:
        return int(val)
    except:
        return None


def sanitize_anchor_id(text):
    if not text: return ""
    return re.sub(r'[^a-z0-9\-]', '', unidecode(str(text)).lower().replace(" ", "-"))


def generate_safe_filename(raw_title):
    return re.sub(r'[^a-z0-9\-]', '', unidecode(raw_title.lower().replace(" ", "-"))) + ".md"


# --- NOTES DE BAS DE PAGE (V331) ---

def init_footnotes_ctx():
    return {"counter": 0, "defs": [] , "seen": set()}

def register_footnote(footnotes_ctx, body_text, explicit_id=None):
    """Enregistre une note de bas de page et retourne son identifiant.
    - explicit_id: identifiant fourni par l'ODT (rare). Sinon, un id séquentiel est généré.
    """
    if footnotes_ctx is None:
        return None

    # Normaliser l'id (Markdown footnotes: [^id])
    if explicit_id:
        fid = sanitize_anchor_id(str(explicit_id))
        fid = fid if fid else None
    else:
        fid = None

    if not fid:
        footnotes_ctx["counter"] += 1
        fid = f"fn{footnotes_ctx['counter']}"

    # Eviter doublons exacts (même id)
    if fid in footnotes_ctx.get("seen", set()):
        return fid

    footnotes_ctx["seen"].add(fid)
    # Nettoyage léger : pas de lignes vides en fin
    body = (body_text or "").strip()
    footnotes_ctx["defs"].append((fid, body))
    return fid

def write_footnotes(current_file, footnotes_ctx):
    """Écrit les définitions de notes à la fin du fichier courant."""
    if not footnotes_ctx:
        return
    defs = footnotes_ctx.get("defs") or []
    if not defs:
        return
    current_file.write("\n\n---\n\n")
    for fid, body in defs:
        if not body:
            body = ""
        # Markdown footnotes: les lignes suivantes doivent être indentées
        lines = body.splitlines() if body else [""]
        current_file.write(f"[^%s]: %s\n" % (fid, lines[0] if lines else ""))
        for ln in lines[1:]:
            current_file.write(f"    {ln}\n")


def escape_markdown_text(s: str) -> str:
    """Escape Markdown special characters in plain text segments.

    Important: This is applied ONLY to raw text nodes (nodeType==3) before any
    Markdown formatting markers (**,* etc.) are injected by apply_formatting().
    """
    if s is None:
        return ""
    # Escape backslash first to avoid interfering with later escapes
    s = s.replace('\\', '\\\\')
    # Escape characters that commonly trigger Markdown parsing in MkDocs/Material
    # (keep this conservative to avoid over-escaping)
    s = s.replace('*', '\\*').replace('_', '\\_')
    return s


# --- BORDURES PARAGRAPHES (V321) ---

def normalize_odf_border_to_css(border_val):
    if not border_val: return None
    v = str(border_val).strip()
    if not v or v.lower() in ("none", "0", "0pt", "0cm"): return None
    m = re.match(
        r'^\s*([0-9]*\.?[0-9]+)\s*(pt|px|cm|mm|in)?\s+(solid|dashed|dotted|double|groove|ridge|inset|outset)\s+([^\s]+)\s*$',
        v, flags=re.I)
    if m:
        w, unit, style_name, color = m.group(1), (m.group(2) or 'pt'), m.group(3).lower(), m.group(4)
        return f"{w}{unit} {style_name} {color}"
    return v


def build_hr_for_border(border_css, where):
    if not border_css: return ""
    return f'<hr style="border:0; border-top:{border_css}; margin:0.75em 0;" data-odt-border="{where}" />\n'


# --- ANALYSE DES STYLES ---

def build_readable_style_map(doc):
    readable_map = {}
    sources = []
    if doc.automaticstyles: sources.extend(doc.automaticstyles.childNodes)
    if doc.styles: sources.extend(doc.styles.childNodes)

    for s in sources:
        if s.tagName == 'style:style':
            internal = get_attribute_safe(s, 'name')
            display = get_attribute_safe(s, 'display-name')
            if internal:
                final = display if display else internal
                readable_map[internal] = final
    return readable_map


def build_style_inheritance_map(doc):
    inheritance = {}
    sources = []
    if doc.automaticstyles: sources.extend(doc.automaticstyles.childNodes)
    if doc.styles: sources.extend(doc.styles.childNodes)

    for s in sources:
        if s.tagName == 'style:style':
            name = get_attribute_safe(s, 'name')
            parent = get_attribute_safe(s, 'parent-style-name')
            if name and parent:
                inheritance[name] = parent
    return inheritance


def get_formatting_styles_with_inheritance(doc, inheritance_map):
    bold_styles = set()
    italic_styles = set()
    underlined_styles = set()
    highlight_colors = {}
    text_colors = {}
    paragraph_borders = {}

    sources = []
    if doc.automaticstyles: sources.extend(doc.automaticstyles.childNodes)
    if doc.styles: sources.extend(doc.styles.childNodes)

    for s in sources:
        if s.tagName == 'style:style':
            name = get_attribute_safe(s, 'name')
            if not name: continue

            name_lower = name.lower()
            if "bold" in name_lower or "gras" in name_lower:
                bold_styles.add(name)

            for child in s.childNodes:
                # Texte
                if child.tagName == 'style:text-properties':
                    fw = get_attribute_safe(child, 'font-weight')
                    fw_asian = get_attribute_safe(child, 'font-weight-asian')
                    fw_complex = get_attribute_safe(child, 'font-weight-complex')
                    is_bold = False
                    for w in [fw, fw_asian, fw_complex]:
                        if w and (w == 'bold' or w == '700' or w == '800' or w == '900'):
                            is_bold = True
                    if is_bold: bold_styles.add(name)

                    us = get_attribute_safe(child, 'text-underline-style')
                    ut = get_attribute_safe(child, 'text-underline-type')
                    uw = get_attribute_safe(child, 'text-underline-width')
                    is_ul = (us and us != 'none') or (ut and ut != 'none') or (uw and uw != '0pt' and uw != '0cm')
                    if is_ul: underlined_styles.add(name)

                    fs = get_attribute_safe(child, 'font-style')
                    fs_asian = get_attribute_safe(child, 'font-style-asian')
                    fs_complex = get_attribute_safe(child, 'font-style-complex')
                    is_italic = False
                    for f in [fs, fs_asian, fs_complex]:
                        if f and (f == 'italic' or f == 'oblique'):
                            is_italic = True
                    if is_italic: italic_styles.add(name)

                    bg = get_attribute_safe(child, 'background-color')
                    if bg and bg != 'transparent':
                        bg_lower = bg.lower()
                        if bg_lower not in ['#ffffff', '#fff', 'white', 'none']:
                            highlight_colors[name] = bg

                    fg = get_attribute_safe(child, 'color')
                    if fg and fg != 'auto' and fg != 'transparent':
                        text_colors[name] = fg

                # Paragraphe (Bordures)
                if child.tagName == 'style:paragraph-properties':
                    border = get_attribute_safe(child, 'border')
                    border_top = get_attribute_safe(child, 'border-top')
                    border_bottom = get_attribute_safe(child, 'border-bottom')

                    b_data = {}
                    if border and border != 'none':
                        css = normalize_odf_border_to_css(border)
                        if css:
                            b_data['top'] = css
                            b_data['bottom'] = css
                    else:
                        if border_top and border_top != 'none':
                            css = normalize_odf_border_to_css(border_top)
                            if css: b_data['top'] = css
                        if border_bottom and border_bottom != 'none':
                            css = normalize_odf_border_to_css(border_bottom)
                            if css: b_data['bottom'] = css

                    if b_data:
                        paragraph_borders[name] = b_data

    # Propagation
    all_styles = set(inheritance_map.keys()).union(bold_styles).union(italic_styles).union(paragraph_borders.keys())
    changed = True
    while changed:
        changed = False
        for s in all_styles:
            p = inheritance_map.get(s)
            if not p: continue

            if p in bold_styles and s not in bold_styles:
                bold_styles.add(s);
                changed = True
            if p in italic_styles and s not in italic_styles:
                italic_styles.add(s);
                changed = True
            if p in underlined_styles and s not in underlined_styles:
                underlined_styles.add(s);
                changed = True
            if p in highlight_colors and s not in highlight_colors:
                highlight_colors[s] = highlight_colors[p];
                changed = True
            if p in text_colors and s not in text_colors:
                text_colors[s] = text_colors[p];
                changed = True
            if p in paragraph_borders and s not in paragraph_borders:
                paragraph_borders[s] = paragraph_borders[p];
                changed = True
            elif p in paragraph_borders and s in paragraph_borders:
                if 'top' in paragraph_borders[p] and 'top' not in paragraph_borders[s]:
                    paragraph_borders[s]['top'] = paragraph_borders[p]['top'];
                    changed = True
                if 'bottom' in paragraph_borders[p] and 'bottom' not in paragraph_borders[s]:
                    paragraph_borders[s]['bottom'] = paragraph_borders[p]['bottom'];
                    changed = True

    return bold_styles, underlined_styles, highlight_colors, italic_styles, text_colors, paragraph_borders


# --- CODE & LISTES ---

def detect_language(code_content, code_config):
    if not code_content: return code_config.get('default_language', 'text')
    content_stripped = code_content.strip()
    if content_stripped.startswith("<?php"): return "php"
    if content_stripped.startswith("<?xml"): return "xml"
    rules = code_config.get('detection_rules', {})
    scores = {}
    for lang, keywords in rules.items():
        count = sum(1 for k in keywords if k in code_content)
        if count > 0: scores[lang] = count
    if scores: return max(scores, key=scores.get)
    if "function" in code_content or "var " in code_content: return "js"
    return code_config.get('default_language', 'text')


def get_fence(content):
    matches = re.findall(r'`+', content)
    longest = max(len(m) for m in matches) if matches else 0
    return "`" * max(3, longest + 1)


def build_list_style_map(doc):
    list_map = {}
    sources = []
    if doc.automaticstyles: sources.extend(doc.automaticstyles.childNodes)
    if doc.styles: sources.extend(doc.styles.childNodes)

    for s in sources:
        if s.tagName != 'text:list-style': continue
        name = get_attribute_safe(s, 'name')
        if not name: continue

        level_map = {}
        for child in s.childNodes:
            if child.tagName in ('text:list-level-style-number', 'text:list-level-style-bullet'):
                lvl = safe_int(get_attribute_safe(child, 'level')) or safe_int(get_attribute_safe(child, 'list-level'))
                if not lvl: continue
                if child.tagName == 'text:list-level-style-number':
                    level_map[lvl] = 'ordered'
                else:
                    level_map[lvl] = 'unordered'

        default_type = 'unordered'
        if level_map: default_type = level_map.get(1, next(iter(level_map.values())))
        list_map[name] = {'levels': level_map, 'default': default_type}
    return list_map


def build_list_chain_map_odfpy(doc):
    lists_db = {}
    all_lists = doc.text.getElementsByType(text.List)
    for lst in all_lists:
        lid = get_attribute_safe(lst, 'id')
        if not lid: continue
        prev = get_attribute_safe(lst, 'continue-list')
        explicit = safe_int(get_attribute_safe(lst, 'start-value'))
        count = sum(1 for child in lst.childNodes if child.tagName == 'text:list-item')
        lists_db[lid] = {'prev': prev, 'explicit': explicit, 'count': count, 'computed': None}

    def resolve(cid, visited):
        if cid in visited or cid not in lists_db: return 1
        d = lists_db[cid]
        if d['computed'] is not None: return d['computed']
        visited.add(cid)
        if d['explicit'] is not None:
            val = d['explicit']
        elif d['prev']:
            pd = lists_db.get(d['prev'])
            val = resolve(d['prev'], visited) + (lists_db[d['prev']]['count'] if pd else 0)
        else:
            val = 1
        d['computed'] = val
        return val

    for lid in lists_db: resolve(lid, set())
    return lists_db


def get_block_start_odfpy(node, list_chain_map):
    curr = node
    for _ in range(6):
        if not hasattr(curr, 'parentNode') or not curr.parentNode: break
        curr = curr.parentNode
        if curr.tagName == 'text:list-item':
            sv = safe_int(get_attribute_safe(curr, 'start-value'))
            if sv: return sv
            parent_list = curr.parentNode
            if parent_list and parent_list.tagName == 'text:list':
                lid = get_attribute_safe(parent_list, 'id')
                if lid and lid in list_chain_map:
                    val = list_chain_map[lid]['computed']
                    if val and val > 1: return val
    return 1


# --- TEXTE ET FORMATAGE ---

def apply_formatting(txt, style_name, bold_styles, underlined_styles, highlight_colors, italic_styles, text_colors,
                     output_format, is_block_context=False):
    if not txt or output_format == "code_html": return txt

    bg_color = highlight_colors.get(style_name)
    if bg_color: txt = f'<mark style="background-color: {bg_color}">{txt}</mark>'

    fg_color = text_colors.get(style_name)
    if fg_color: txt = f'<span style="color: {fg_color}">{txt}</span>'

    if is_block_context: return txt

    is_bold = style_name and style_name in bold_styles
    is_italic = style_name and style_name in italic_styles
    is_underlined = style_name and style_name in underlined_styles

    if is_bold:
        txt = f"**{txt}**" if output_format == "md" else f"<b>{txt}</b>"
    if is_italic:
        txt = f"*{txt}*" if output_format == "md" else f"<i>{txt}</i>"
    if is_underlined:
        txt = f"<u>{txt}</u>"
    return txt


def has_image_child(node):
    for child in node.childNodes:
        if child.tagName == 'draw:image': return True
        if has_image_child(child): return True
    return False


def clean_text(node, escape=False, bold_styles=None, underlined_styles=None, highlight_colors=None, italic_styles=None,
               text_colors=None, output_format="md", targets_map=None, current_filename=None, footnotes_ctx=None):
    if bold_styles is None: bold_styles = set()
    if italic_styles is None: italic_styles = set()
    if underlined_styles is None: underlined_styles = set()
    if highlight_colors is None: highlight_colors = {}
    if text_colors is None: text_colors = {}
    if targets_map is None: targets_map = {}
    if current_filename is None: current_filename = "index.md"

    txt = ""
    for child in node.childNodes:
        if child.tagName == 'draw:frame' and has_image_child(child): continue

        # V326: Si on veut du texte brut (ex: pour un titre de TOC), on IGNORE les ancres.
        # Cela règle définitivement le bug des ancres dans la table des matières.
        if output_format == "txt":
            if child.tagName in ('text:bookmark', 'text:bookmark-start', 'text:reference-mark',
                                 'text:reference-mark-start'):
                continue  # Skip anchors in txt mode


        # V331: Notes de bas de page
        if child.tagName == 'text:note':
            if output_format == "txt":
                continue
            # Extraire une éventuelle citation explicite et le corps
            explicit = None
            body_node = None
            for nchild in child.childNodes:
                if nchild.tagName == 'text:note-citation':
                    explicit = clean_text(nchild, escape=False, output_format="txt", targets_map=targets_map,
                                          current_filename=current_filename, footnotes_ctx=footnotes_ctx)
                elif nchild.tagName == 'text:note-body':
                    body_node = nchild
            body_txt = ""
            if body_node is not None:
                body_txt = clean_text(body_node, escape=True, bold_styles=bold_styles,
                                      underlined_styles=underlined_styles, highlight_colors=highlight_colors,
                                      italic_styles=italic_styles, text_colors=text_colors, output_format="md",
                                      targets_map=targets_map, current_filename=current_filename,
                                      footnotes_ctx=footnotes_ctx)
                # Dans une définition de note, éviter de ré-injecter des ancres HTML vides
                body_txt = re.sub(r'<a id="[^"]+"></a>', '', body_txt).strip()
            fid = register_footnote(footnotes_ctx, body_txt, explicit_id=explicit)
            if fid:
                txt += f"[^{fid}]"
            continue

        # V326: Gestion des Repères et Renvois (Bookmarks & References)
        if child.tagName == 'text:bookmark':
            name = get_attribute_safe(child, 'name')
            if name and output_format != "txt": txt += f'<a id="{sanitize_anchor_id(name)}"></a>'

        elif child.tagName == 'text:bookmark-start':
            name = get_attribute_safe(child, 'name')
            if name and output_format != "txt": txt += f'<a id="{sanitize_anchor_id(name)}"></a>'

        elif child.tagName in ('text:reference-mark', 'text:reference-mark-start'):
            name = get_attribute_safe(child, 'name')
            if name and output_format != "txt": txt += f'<a id="{sanitize_anchor_id(name)}"></a>'

        elif child.tagName in ('text:reference-ref', 'text:bookmark-ref'):
            ref_name = get_attribute_safe(child, 'ref-name')
            # Récursion pour avoir le texte du lien
            inner = clean_text(child, escape, bold_styles, underlined_styles, highlight_colors, italic_styles,
                               text_colors, output_format, targets_map, current_filename, footnotes_ctx=footnotes_ctx)

            if ref_name and output_format == "md":
                target_file = targets_map.get(ref_name)
                anchor = sanitize_anchor_id(ref_name)
                # Lien intelligent inter-fichiers
                if not target_file or target_file == current_filename:
                    txt += f'[{inner}](#{anchor})'
                else:
                    txt += f'[{inner}]({target_file}#{anchor})'
            else:
                txt += inner

        elif child.nodeType == 3:
            data = str(child.data)
            if escape:
                # HTML escaping first (for safety); then Markdown escaping for plain text segments
                data = html.escape(data)
                if output_format == "md":
                    data = data.replace("<", "&lt;").replace(">", "&gt;")
                    data = escape_markdown_text(data)
            txt += data
        elif child.tagName == 'text:s':
            c = get_attribute_safe(child, 'c')
            txt += " " * (int(c) if c else 1)
        elif child.tagName == 'text:tab':
            txt += "    "
        elif child.tagName == 'text:line-break':
            txt += "<br>" if output_format == "html" else "\n"
        elif child.tagName == 'text:a':
            ls = get_attribute_safe(child, 'style-name')
            inner = clean_text(child, escape, bold_styles, underlined_styles, highlight_colors, italic_styles,
                               text_colors, output_format, targets_map, current_filename, footnotes_ctx=footnotes_ctx)
            href = get_attribute_safe(child, 'href')
            if output_format == "md":
                txt += f"[{inner}]({href})"
            else:
                txt += f'<a href="{href}">{inner}</a>'
        elif child.tagName == 'text:span':
            ss = get_attribute_safe(child, 'style-name')
            inner = clean_text(child, escape, bold_styles, underlined_styles, highlight_colors, italic_styles,
                               text_colors, output_format, targets_map, current_filename, footnotes_ctx=footnotes_ctx)
            inner = apply_formatting(inner, ss, bold_styles, underlined_styles, highlight_colors, italic_styles,
                                     text_colors, output_format)
            txt += inner
        else:
            txt += clean_text(child, escape, bold_styles, underlined_styles, highlight_colors, italic_styles,
                              text_colors, output_format, targets_map, current_filename, footnotes_ctx=footnotes_ctx)
    return txt


# --- IMAGES ---

def extract_images_from_zip(odt_path, output_dir):
    images_map = {}
    if not zipfile.is_zipfile(odt_path): return {}
    with zipfile.ZipFile(odt_path, 'r') as z:
        for file_info in z.infolist():
            if file_info.filename.startswith('Pictures/') and not file_info.filename.endswith('/'):
                original_name = os.path.basename(file_info.filename)
                safe_name = re.sub(r'[^a-zA-Z0-9._-]', '_', original_name)
                target_path = os.path.join(output_dir, safe_name)
                with open(target_path, 'wb') as f: f.write(z.read(file_info))
                images_map[file_info.filename] = f"images/{safe_name}"
    return images_map


def get_image_dimensions(image_node):
    parent = image_node.parentNode
    width = get_attribute_safe(parent, 'width') if parent and parent.tagName == 'draw:frame' else None
    height = get_attribute_safe(parent, 'height') if parent and parent.tagName == 'draw:frame' else None
    return width, height


def extract_image_tag_from_node(node, images_map):
    md = ""
    for img in node.getElementsByType(draw.Image):
        href = get_attribute_safe(img, 'href')
        if href:
            target = href if href in images_map else href.replace("./", "")
            if target in images_map:
                src = images_map[target]
                width, height = get_image_dimensions(img)
                style = ""
                if width: style += f"width:{width};"
                if height: style += f"height:{height};"
                if not style: style = "max-width:100%;height:auto;"
                md += f'\n<img src="{src}" style="{style}" alt="Image" />\n'
    return md


def get_images_in_node_as_html(node, images_map):
    html_out = ""
    for img in node.getElementsByType(draw.Image):
        href = get_attribute_safe(img, 'href')
        if href:
            target = href if href in images_map else href.replace("./", "")
            if target in images_map:
                src = images_map[target]
                width, height = get_image_dimensions(img)
                style = "display:inline-block; margin:4px;"
                if width: style += f"width:{width};"
                if height:
                    style += f"height:{height};"
                else:
                    style += "max-width:100%;height:auto;"
                html_out += f'<img src="{src}" style="{style}" />'
    return html_out


# --- NAVIGATION ---

def get_readable_style_name(internal, readable_map, inheritance_map):
    curr = internal
    for _ in range(10):
        if not curr: break
        if curr in readable_map: return readable_map[curr]
        curr = inheritance_map.get(curr)
    return internal


def get_heading_level(node, readable_map, inheritance_map):
    if node.tagName == 'text:h':
        lvl = get_attribute_safe(node, 'outline-level')
        return int(lvl) if lvl else 1
    if node.tagName == 'text:p':
        style_name = get_attribute_safe(node, 'style-name')
        if not style_name: return 0
        readable = get_readable_style_name(style_name, readable_map, inheritance_map)
        s_clean = unidecode(readable).lower() if readable else ""
        if any(x in s_clean for x in ['normal', 'standard', 'text body', 'default']): return 0
        match = re.search(r"^(titre|heading|h|chapitre)\s*(\d+)", s_clean)
        if match: return int(match.group(2))
        outline = get_attribute_safe(node, 'outline-level')
        if outline: return int(outline)
    return 0


def is_code_paragraph(node, readable_map, inheritance_map, style_keywords):
    if node.tagName != 'text:p': return False
    curr = get_attribute_safe(node, 'style-name')
    targets = set(style_keywords)
    for _ in range(10):
        if not curr: break
        readable = get_readable_style_name(curr, readable_map, inheritance_map)
        s_clean = unidecode(readable).lower()
        if any(t in s_clean for t in targets): return True
        curr = inheritance_map.get(curr)
    return False


# --- SCANNER V326 ---

def recursive_scan_for_bookmarks(node, current_filename, targets_map):
    # Cherche les bookmarks dans ce noeud et ses enfants
    if hasattr(node, 'tagName'):
        if node.tagName in ('text:bookmark', 'text:bookmark-start', 'text:reference-mark', 'text:reference-mark-start'):
            name = get_attribute_safe(node, 'name')
            if name:
                targets_map[name] = current_filename

    for child in node.childNodes:
        recursive_scan_for_bookmarks(child, current_filename, targets_map)


# --- FLUX NODE STREAM ---

def stream_nodes_context(node, readable_map, inheritance_map, list_style_map, list_level=0, list_type='unordered'):
    if node.tagName in ('office:text', 'text:section', 'draw:frame', 'draw:text-box'):
        for child in node.childNodes:
            yield from stream_nodes_context(child, readable_map, inheritance_map, list_style_map, list_level, list_type)
        return
    if node.tagName == 'table:table':
        yield (node, list_level, list_type)
        return
    if node.tagName == 'text:p' and has_nested_table(node):
        buffer = []
        for child in node.childNodes:
            if child.tagName in ('draw:frame', 'draw:text-box'):
                if buffer:
                    p = text.P();
                    p.childNodes = buffer
                    yield (p, list_level, list_type)
                    buffer = []
                yield from stream_nodes_context(child, readable_map, inheritance_map, list_style_map, list_level,
                                                list_type)
            else:
                buffer.append(child)
        if buffer: p = text.P(); p.childNodes = buffer; yield (p, list_level, list_type)
        return
    if node.tagName == 'text:list':
        style_name = get_attribute_safe(node, 'style-name')
        style_info = list_style_map.get(style_name)
        new_level = list_level + 1
        if isinstance(style_info, dict):
            new_type = style_info.get('levels', {}).get(new_level, style_info.get('default', 'unordered'))
        else:
            new_type = style_info if style_info else 'unordered'
        for child in node.childNodes:
            if child.tagName == 'text:list-item':
                for item_child in child.childNodes:
                    if item_child.tagName == 'text:list':
                        yield from stream_nodes_context(item_child, readable_map, inheritance_map, list_style_map,
                                                        new_level, new_type)
                    else:
                        yield from stream_nodes_context(item_child, readable_map, inheritance_map, list_style_map,
                                                        new_level, new_type)
        return
    yield (node, list_level, list_type)


def has_nested_table(node):
    if node.tagName == 'table:table': return True
    for child in node.childNodes:
        if has_nested_table(child): return True
    return False


def get_all_rows(node):
    rows = []
    if node.tagName == 'table:table-row':
        rows.append(node)
    elif node.tagName in ('table:table', 'table:table-header-rows', 'table:table-footer-rows', 'table:table-row-group'):
        for child in node.childNodes: rows.extend(get_all_rows(child))
    return rows


def process_table_to_html(table_node, images_map, bold_styles, underlined_styles, highlight_colors, italic_styles,
                          text_colors, paragraph_borders, readable_map, inheritance_map, list_chain_map, config,
                          targets_map, current_filename, footnotes_ctx=None):
    html_out = ['<table class="odt-table" style="border-collapse: collapse; width: 100%; margin-bottom: 1em;">']
    all_rows = get_all_rows(table_node)
    if not all_rows: return ""
    style_keywords = config['code']['style_keywords']

    for row in all_rows:
        html_out.append('<tr>')
        for cell in row.childNodes:
            if cell.tagName == 'table:covered-table-cell': continue
            if cell.tagName == 'table:table-cell':
                colspan = get_attribute_safe(cell, 'number-columns-spanned')
                rowspan = get_attribute_safe(cell, 'number-rows-spanned')
                attrs = ' style="border: 1px solid #ddd; padding: 8px; vertical-align: top;"'
                if colspan: attrs += f' colspan="{colspan}"'
                if rowspan: attrs += f' rowspan="{rowspan}"'
                html_out.append(f'<td{attrs}>')

                cell_buffer = []
                code_buffer = []
                code_start_line = 1
                code_has_linenums = False

                def flush_code():
                    nonlocal code_start_line, code_has_linenums
                    if code_buffer:
                        full_code = "\n".join(code_buffer)
                        lang = detect_language(full_code, config['code'])
                        fence = get_fence(full_code)
                        header = f'{fence}{lang}' + (f' linenums="{code_start_line}"' if code_has_linenums else '')
                        cell_buffer.append(
                            f'<div markdown="block">\n{header}\n{full_code}\n{fence}\n</div>')
                        code_buffer.clear()
                        code_start_line = 1
                        code_has_linenums = False

                def extract_cell_content(n, prefix=""):
                    nonlocal code_start_line, code_has_linenums
                    if n.tagName == 'text:p':
                        is_code = is_code_paragraph(n, readable_map, inheritance_map, style_keywords)
                        if is_code:
                            if not code_buffer:
                                ln = get_attribute_safe(n, 'line-number')
                                code_has_linenums = (ln is not None)
                                code_start_line = int(ln) if ln else 1
                            code_buffer.append(clean_text(n, escape=False))
                        else:
                            flush_code()
                            p_style = get_attribute_safe(n, 'style-name')
                            # V325: Update clean_text call
                            txt = clean_text(n, escape=True, bold_styles=bold_styles,
                                             underlined_styles=underlined_styles, highlight_colors=highlight_colors,
                                             italic_styles=italic_styles, text_colors=text_colors, output_format="html",
                                             targets_map=targets_map, current_filename=current_filename, footnotes_ctx=footnotes_ctx)
                            txt = apply_formatting(txt, p_style, bold_styles, underlined_styles, highlight_colors,
                                                   italic_styles, text_colors, output_format="html")
                            img = get_images_in_node_as_html(n, images_map)

                            b = paragraph_borders.get(p_style) if p_style else None
                            if b and b.get('top'): cell_buffer.append(build_hr_for_border(b.get('top'), 'top'))
                            if txt.strip():
                                cell_buffer.append(f'<p style="margin:0;">{prefix}{txt}</p>')
                                if b and b.get('bottom'): cell_buffer.append(
                                    build_hr_for_border(b.get('bottom'), 'bottom'))
                            if img: cell_buffer.append(img)
                    elif n.tagName == 'text:list':
                        flush_code()
                        for item in n.childNodes:
                            if item.tagName == 'text:list-item':
                                for c in item.childNodes: extract_cell_content(c, prefix="&bull; ")
                        flush_code()
                    elif n.tagName == 'table:table':
                        flush_code()
                        cell_buffer.append(
                            process_table_to_html(n, images_map, bold_styles, underlined_styles, highlight_colors,
                                                  italic_styles, text_colors, paragraph_borders, readable_map,
                                                  inheritance_map, list_chain_map, config, targets_map,
                                                  current_filename, footnotes_ctx=footnotes_ctx))
                    else:
                        for c in n.childNodes: extract_cell_content(c, prefix)

                for child in cell.childNodes: extract_cell_content(child)
                flush_code()
                html_out.append("".join(cell_buffer) if cell_buffer else "&nbsp;")
                html_out.append('</td>')
        html_out.append('</tr>')
    html_out.append('</table>')
    return "".join(html_out)


# --- MAIN & BUILDERS ---

def generate_focus_assets(docs_dir):
    js_dir = os.path.join(docs_dir, "javascripts")
    css_dir = os.path.join(docs_dir, "stylesheets")
    create_directory(js_dir);
    create_directory(css_dir)
    with open(os.path.join(css_dir, "focus.css"), "w", encoding="utf-8") as f:
        f.write(
            "body.md-focus .md-sidebar--primary { display: none; } body.md-focus .md-sidebar--secondary { display: none; } body.md-focus .md-content { max-width: 95%; margin: 0 auto; } .focus-toggle-btn { cursor: pointer; margin-left: 0.5rem; } .odt-table img { max-width: 100%; height: auto; }")
    with open(os.path.join(js_dir, "focus.js"), "w", encoding="utf-8") as f:
        f.write(
            'document.addEventListener("DOMContentLoaded",function(){if(document.querySelector(".focus-toggle-btn"))return;var e=document.createElement("label");e.className="md-icon md-header__button focus-toggle-btn",e.title="Mode Focus",e.innerHTML=\'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3M14 5v2h3v3h2V5h-5Z"></path></svg>\';var t=document.querySelector(".md-header__inner");t&&t.appendChild(e),e.addEventListener("click",function(){document.body.classList.toggle("md-focus"),document.body.classList.contains("md-focus")?e.innerHTML=\'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 16h3v3h2v-5H5v2m3-8H5v2h5V5H8v3m6 11h2v-3h3v-2h-5v5m2-11V5h-2v5h5V8h-3Z"></path></svg>\':e.innerHTML=\'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5m12 7h-3v2h5v-5h-2v3M14 5v2h3v3h2V5h-5Z"></path></svg>\'})});')


def generate_mkdocs_yml(nav_structure, config_data):
    mk = config_data.get('mkdocs', {})
    use_dir = "true" if mk.get('use_directory_urls', False) else "false"

    out = ""
    out += f"site_name: \"{mk.get('site_name', 'My Site')}\"\n"
    out += f"site_url: \"{mk.get('site_url', '')}\"\n"
    out += f"site_description: \"{mk.get('site_description', '')}\"\n"
    out += f"site_author: \"{mk.get('site_author', '')}\"\n"
    out += f"use_directory_urls: {use_dir}\n"
    out += f"repo_url: \"{mk.get('repo_url', '')}\"\n"
    out += f"repo_name: \"{mk.get('repo_name', 'GitHub')}\"\n\n"

    theme_conf = mk.get('theme', {})
    out += "theme:\n"
    out += f"  name: {theme_conf.get('name', 'material')}\n"
    if 'custom_dir' in theme_conf:
        out += f"  custom_dir: {theme_conf['custom_dir']}\n"

    if 'features' in theme_conf:
        out += "  features:\n"
        for f in theme_conf['features']:
            out += f"    - {f}\n"

    if 'palette' in theme_conf:
        out += "  palette:\n"
        for pal in theme_conf['palette']:
            out += "    - media: \"" + pal.get('media', '') + "\"\n"
            out += "      scheme: " + pal.get('scheme', 'default') + "\n"
            out += "      primary: " + pal.get('primary', 'teal') + "\n"
            out += "      accent: " + pal.get('accent', 'purple') + "\n"
            if 'toggle' in pal:
                out += "      toggle:\n"
                out += "        icon: " + pal['toggle'].get('icon', '') + "\n"
                out += "        name: " + pal['toggle'].get('name', '') + "\n"

    out += "\n"

    md_exts = mk.get('markdown_extensions', [])
    if md_exts:
        out += "markdown_extensions:\n"
        for ext in md_exts:
            if isinstance(ext, str):
                out += f"  - {ext}\n"
            elif isinstance(ext, dict):
                for k, v in ext.items():
                    out += f"  - {k}:\n"
                    if isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            val = 'null' if (k == "pymdownx.highlight" and sub_k == "linenums") else (
                                str(sub_v).lower() if isinstance(sub_v, bool) else sub_v)
                            out += f"      {sub_k}: {val}\n"

    out += "\n"
    out += "extra_javascript: [javascripts/focus.js]\n"
    out += "extra_css: [stylesheets/focus.css]\n\n"

    out += "nav:\n"
    for item in nav_structure:
        for k, v in item.items():
            safe_key = json.dumps(k, ensure_ascii=False)
            out += f"  - {safe_key}: {v}\n"

    extra_data = config_data.get('extra', {})
    if extra_data:
        out += "\nextra:\n"
        if 'analytics' in extra_data:
            an = extra_data['analytics']
            out += f"  analytics:\n    provider: {an.get('provider', 'google')}\n    property: {an.get('property', '')}\n"

    with open("mkdocs.yml", "w", encoding="utf-8") as f:
        f.write(out)


def convert_odt_to_site(odt_file, config_file):
    print(f"--- ODT to MkDocs Converter {VERSION} ---")
    if not os.path.exists(odt_file): return print(f"Erreur: {odt_file} introuvable.")
    config = load_configuration(config_file)
    is_debug = config.get('debug', True)

    print(f"Traitement de {odt_file}...")
    if os.path.exists("docs"): shutil.rmtree("docs", ignore_errors=True)
    create_directory("docs");
    create_directory("docs/images");
    create_directory("overrides/partials/integrations")

    files_list = config.get('files_to_copy', [])
    for f in files_list:
        if os.path.exists(f):
            try:
                shutil.copy(f, os.path.join("docs", f));
                print(f"Copié : {f}")
            except Exception as e:
                print(f"Erreur copie {f}: {e}")

    generate_focus_assets("docs")
    with open("overrides/partials/footer.html", "w", encoding="utf-8") as f:
        f.write(config.get('footer', '<footer></footer>'))

    analytics_content = """{% if config.extra.analytics %}
  <script async src="https://www.googletagmanager.com/gtag/js?id={{ config.extra.analytics.property }}"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    var siteName = "{{ config.site_name | replace('\\"', '\\\\\"') }}";
    gtag('config', '{{ config.extra.analytics.property }}', {
        'page_title': siteName
    });
  </script>
{% endif %}"""
    with open("overrides/partials/integrations/analytics.html", "w", encoding="utf-8") as f:
        f.write(analytics_content)
    with open("overrides/partials/analytics.html", "w", encoding="utf-8") as f:
        f.write(analytics_content)

    doc = load(odt_file)
    images_map = extract_images_from_zip(odt_file, "docs/images")
    readable_map = build_readable_style_map(doc)
    inheritance_map = build_style_inheritance_map(doc)
    list_style_map = build_list_style_map(doc)

    # V321: Get colors and borders
    bold_styles, underlined_styles, highlight_colors, italic_styles, text_colors, paragraph_borders = get_formatting_styles_with_inheritance(
        doc, inheritance_map)
    list_chain_map = build_list_chain_map_odfpy(doc)

    # --- PASSE 1 : SCAN DES CIBLES (Repères -> Fichiers) ---
    print("Scan des renvois...")
    targets_map = {}
    current_scan_file = "index.md"

    # On itère pour repérer les cibles
    for node, list_level, list_type in stream_nodes_context(doc.text, readable_map, inheritance_map, list_style_map):
        heading_level = 0
        if node.tagName in ('text:p', 'text:h'):
            heading_level = get_heading_level(node, readable_map, inheritance_map)

        if heading_level == 1:
            # On utilise txt pur pour le nom de fichier, sans ancres
            raw_txt = clean_text(node, escape=False, output_format="txt")
            current_scan_file = generate_safe_filename(raw_txt)

        recursive_scan_for_bookmarks(node, current_scan_file, targets_map)

    # --- PASSE 2 : GÉNÉRATION ---

    nav = [{"Accueil": "index.md"}]
    current_file = open("docs/index.md", "w", encoding="utf-8")
    current_filename_str = "index.md"
    footnotes_ctx = init_footnotes_ctx()

    counters = [0] * 10
    code_buffer = []
    code_start_line = 1
    code_has_linenums = False

    found_first_h1 = False
    doc_title_config = config.get('document_title', {})
    target_styles = [unidecode(s).lower().strip() for s in doc_title_config.get('style_names', [])]
    previous_was_list = False
    prev_list_level = 0

    print("Génération Markdown...")

    for node, list_level, list_type in stream_nodes_context(doc.text, readable_map, inheritance_map, list_style_map):

        # Gestion robuste des transitions liste / hors-liste.
        # - Ajoute une ligne vide en sortie de liste.
        # - Force un saut de ligne AVANT la première puce/numéro pour garantir un début de ligne.
        if prev_list_level > 0 and list_level == 0:
            current_file.write("\n")
        if prev_list_level == 0 and list_level > 0:
            current_file.write("\n")
        prev_list_level = list_level
        previous_was_list = (list_level > 0)

        # DEBUG PRE-H1
        if is_debug and not found_first_h1:
            if node.tagName in ('text:p', 'text:h'):
                dbg_style = get_attribute_safe(node, 'style-name')
                dbg_read = get_readable_style_name(dbg_style, readable_map, inheritance_map)
                dbg_txt = clean_text(node)[:50]
                print(f"[DEBUG PRE-H1] Tag={node.tagName} Style='{dbg_read}' Text='{dbg_txt}...'")

        # TABLEAU
        if node.tagName == 'table:table':
            current_file.write(
                process_table_to_html(node, images_map, bold_styles, underlined_styles, highlight_colors, italic_styles,
                                      text_colors, paragraph_borders, readable_map, inheritance_map, list_chain_map,
                                      config, targets_map, current_filename_str, footnotes_ctx=footnotes_ctx) + "\n\n")
            continue

        # TITRE DOC
        if node.tagName in ('text:p', 'text:h'):
            p_style = get_attribute_safe(node, 'style-name')
            readable = get_readable_style_name(p_style, readable_map, inheritance_map)
            s_clean = unidecode(readable).lower().strip() if readable else ""
            if s_clean in target_styles:
                txt = clean_text(node, escape=True, bold_styles=bold_styles, underlined_styles=underlined_styles,
                                 highlight_colors=highlight_colors, italic_styles=italic_styles,
                                 text_colors=text_colors, output_format="md", targets_map=targets_map,
                                 current_filename=current_filename_str, footnotes_ctx=footnotes_ctx)
                txt = apply_formatting(txt, p_style, set(), set(), highlight_colors, set(), text_colors,
                                       output_format="md", is_block_context=True)
                current_file.write(f'<p style="{doc_title_config.get("css", "")}">{txt}</p>\n\n')
                print(f">>> TITRE DOCUMENT TROUVÉ : {txt}")
                continue

        # CHAPITRES
        heading_level = 0
        if node.tagName in ('text:p', 'text:h'):
            heading_level = get_heading_level(node, readable_map, inheritance_map)

        if heading_level > 0:
            found_first_h1 = True
            if code_buffer:
                full = "\n".join(code_buffer);
                fence = get_fence(full);
                lang = detect_language(full, config['code'])
                indent = "    " * list_level
                header = f"{indent}{fence}{lang}" + (f' linenums="{code_start_line}"' if code_has_linenums else '')
                current_file.write(
                    f"\n{header}\n" + "\n".join([f"{indent}{l}" for l in code_buffer]) + f"\n{indent}{fence}\n\n")
                code_buffer = []
                code_has_linenums = False

            # TEXTE BRUT (pour log et nom de fichier)
            # V326: Important - output_format="txt" ne génère PAS d'ancres HTML
            raw_title_text = clean_text(node, escape=False, output_format="txt")

            # TEXTE FORMATÉ (pour affichage dans le fichier)
            # V326: Ici on génère le MD. Les ancres seront générées si présentes
            formatted_title_text = clean_text(node, escape=True, bold_styles=bold_styles,
                                              underlined_styles=underlined_styles, highlight_colors=highlight_colors,
                                              italic_styles=italic_styles, text_colors=text_colors, output_format="md",
                                              targets_map=targets_map, current_filename=current_filename_str, footnotes_ctx=footnotes_ctx).strip()

            # V326: Extraction propre des ancres pour mise en forme
            anchors = re.findall(r'<a id="[^"]+"></a>', formatted_title_text)
            clean_title = re.sub(r'<a id="[^"]+"></a>', '', formatted_title_text).strip()

            p_style = get_attribute_safe(node, 'style-name')
            final_display_title = apply_formatting(clean_title, p_style, set(), set(), highlight_colors, set(),
                                                   text_colors, output_format="md", is_block_context=True)

            counters[heading_level - 1] += 1
            for i in range(heading_level, 10): counters[i] = 0
            num_str = ".".join(str(counters[i]) for i in range(heading_level)) if heading_level > 1 else str(
                counters[0])

            print(f">>> CHAPITRE {heading_level}: {num_str} {raw_title_text}")

            if heading_level == 1:
                write_footnotes(current_file, footnotes_ctx)
                current_file.close()
                fname = generate_safe_filename(raw_title_text)
                current_filename_str = fname  # Mise à jour pour les futurs liens

                current_file = open(f"docs/{fname}", "w", encoding="utf-8")
                footnotes_ctx = init_footnotes_ctx()
                # Write anchors first
                if anchors: current_file.write("\n".join(anchors) + "\n\n")
                current_file.write(f"# {num_str}. {final_display_title}\n\n")
                nav.append({f"{num_str}. {raw_title_text}": fname})
            else:
                # Write anchors first
                if anchors: current_file.write("\n".join(anchors) + "\n\n")
                current_file.write(f"{'#' * heading_level} {num_str}. {final_display_title}\n\n")
            continue

        # LISTE
        if node.tagName == 'text:list-item':
            parts = []
            for child in node.childNodes:
                if child.tagName == 'text:p':
                    p_style = get_attribute_safe(child, 'style-name')
                    # V325: Update clean_text
                    txt = clean_text(child, escape=True, bold_styles=bold_styles, underlined_styles=underlined_styles,
                                     highlight_colors=highlight_colors, italic_styles=italic_styles,
                                     text_colors=text_colors, output_format="md", targets_map=targets_map,
                                     current_filename=current_filename_str, footnotes_ctx=footnotes_ctx)
                    txt = apply_formatting(txt, p_style, bold_styles, underlined_styles, highlight_colors,
                                           italic_styles, text_colors, output_format="md", is_block_context=True)
                    parts.append(txt)
            full = " ".join(parts).strip()
            if full: current_file.write(f"- {full}\n")
            continue

        # CODE
        if node.tagName == 'text:p' and is_code_paragraph(node, readable_map, inheritance_map,
                                                          config['code']['style_keywords']):
            if not code_buffer:
                ln = get_attribute_safe(node, 'line-number')
                sv = None
                if hasattr(node, 'parentNode') and node.parentNode.tagName == 'text:list-item':
                    sv = get_attribute_safe(node.parentNode, 'start-value')
                # Numérotation des blocs de code :
                # - On n'active linenums QUE si le document ODT numérote réellement le bloc (attribut line-number
                #   ou bloc inséré dans une liste numérotée avec un start-value / continuation détectée).
                v_list = get_block_start_odfpy(node, list_chain_map)
                code_start_line = v_list if v_list > 1 else (int(ln) if ln else 1)

                is_numbered_list_context = (list_level > 0 and list_type == "ordered")

                code_has_linenums = (ln is not None) or (sv is not None) or (v_list and v_list > 1) or is_numbered_list_context

            code_buffer.append(clean_text(node))
            continue

        if code_buffer:
            full = "\n".join(code_buffer)
            fence = get_fence(full)
            lang = detect_language(full, config['code'])
            indent = "    " * list_level
            header = f"{indent}{fence}{lang}" + (f' linenums="{code_start_line}"' if code_has_linenums else '')
            current_file.write(
                f"\n{header}\n" + "\n".join([f"{indent}{l}" for l in code_buffer]) + f"\n{indent}{fence}\n")
            # IMPORTANT: vider le buffer ici, sinon le même bloc est réémis plus loin (duplication)
            code_buffer = []
            code_start_line = 1
            code_has_linenums = False

        # TEXTE STANDARD
        if node.tagName in ('text:p', 'text:h'):
            p_style = get_attribute_safe(node, 'style-name')
            # V325: Update clean_text
            txt = clean_text(node, escape=True, bold_styles=bold_styles, underlined_styles=underlined_styles,
                             highlight_colors=highlight_colors, italic_styles=italic_styles, text_colors=text_colors,
                             output_format="md", targets_map=targets_map, current_filename=current_filename_str, footnotes_ctx=footnotes_ctx)
            txt = apply_formatting(txt, p_style, bold_styles, underlined_styles, highlight_colors, italic_styles,
                                   text_colors, output_format="md")
            img = extract_image_tag_from_node(node, images_map)

            b = paragraph_borders.get(p_style) if p_style else None

            if txt.strip():
                if list_level > 0:
                    indent = "    " * (list_level - 1)
                    marker = "1. " if list_type == 'ordered' else "- "
                    current_file.write(f"{indent}{marker}{txt}\n")
                else:
                    if b and b.get('top'): current_file.write(build_hr_for_border(b.get('top'), 'top'))
                    current_file.write(f"{txt}\n\n")
                    if b and b.get('bottom'): current_file.write(build_hr_for_border(b.get('bottom'), 'bottom'))
            if img: current_file.write(f"{img}\n\n")


    # Flush final : évite de perdre ou de dupliquer le dernier bloc de code si le document se termine par du code
    if code_buffer:
        full = "\n".join(code_buffer)
        fence = get_fence(full)
        lang = detect_language(full, config['code'])
        indent = "    " * 0
        header = f"{indent}{fence}{lang}" + (f' linenums="{code_start_line}"' if code_has_linenums else '')
        current_file.write(
            f"\n{header}\n" + "\n".join([f"{indent}{l}" for l in code_buffer]) + f"\n{indent}{fence}\n\n")
        code_buffer = []
        code_start_line = 1
        code_has_linenums = False

    write_footnotes(current_file, footnotes_ctx)
    current_file.close()
    generate_mkdocs_yml(nav, config)
    print("Terminé.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python convert.py <fichier.odt> <config.json>")
    else:
        convert_odt_to_site(sys.argv[1], sys.argv[2])