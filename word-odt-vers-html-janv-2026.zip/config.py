config = {
    # -------------------------------------------------------------------------
    # Configuration MkDocs
    # -------------------------------------------------------------------------
    "mkdocs": {
        # Titre du site qui apparaîtra dans l'onglet du navigateur
        "site_name": "Convertir un document Word ou ODT vers un site statique HTML à l'aide des IA Gemini 3 et ChatGPT 5.2",

        # URL de publication du site (ex: GitHub Pages)
        "site_url": "https://stahe.github.io/word-odt-vers-html-janv-2026/",

        # Méta-description pour le référencement (SEO)
        "site_description": "Convertir un document Word ou ODT vers un site statique HTML à l'aide des IA Gemini 3 et ChatGPT 5.2",

        # Auteur du site
        "site_author": "Serge Tahé",

        # Lien vers le dépôt de code source (icône GitHub en haut à droite)
        "repo_url": "https://stahe.github.io/word-odt-vers-html-janv-2026",
        "repo_name": "GitHub",

        # Important : à False pour que les liens fonctionnent correctement sur GitHub Pages
        # (évite les liens du type dossier/ au lieu de dossier/index.html)
        "use_directory_urls": False,

        # Configuration du thème Material pour MkDocs
        "theme": {
            "name": "material",
            # Dossier contenant les surcharges (footer personnalisé, etc.)
            "custom_dir": "overrides",

            # Fonctionnalités de navigation activées
            "features": [
                "navigation.sections",  # Regroupe les sections dans le menu
                "navigation.indexes",  # Permet de cliquer sur le titre de section
                "navigation.expand",  # Ouvre les menus par défaut
                "toc.integrate",  # Intègre la table des matières à gauche (si supporté)
                "navigation.top"  # Bouton "Retour en haut"
            ],

            # Palette de couleurs (Mode Clair / Mode Sombre)
            "palette": [
                {
                    "media": "(prefers-color-scheme: light)",
                    "scheme": "default",
                    "primary": "teal",
                    "accent": "purple",
                    "toggle": {
                        "icon": "material/brightness-7",
                        "name": "Passer au mode sombre"
                    }
                },
                {
                    "media": "(prefers-color-scheme: dark)",
                    "scheme": "slate",
                    "primary": "teal",
                    "accent": "purple",
                    "toggle": {
                        "icon": "material/brightness-4",
                        "name": "Passer au mode clair"
                    }
                }
            ]
        },

        # Extensions Markdown utilisées pour enrichir le contenu
        "markdown_extensions": [
            "admonition",  # Blocs d'avertissement/info
            "attr_list",  # Attributs CSS personnalisés {: .class }
            "pymdownx.superfences",  # Blocs de code avancés
            "pymdownx.mark",  # Surlignage ==texte==
            {
                "pymdownx.highlight": {
                    "anchor_linenums": True,
                    "linenums": None  # La numérotation est gérée dynamiquement par le script
                }
            },
            "md_in_html",  # Autorise le Markdown dans les balises HTML (crucial pour les listes et tableaux)
            "footnotes"  # Notes de bas de page [^1]
        ],

        # Scripts et CSS additionnels
        "extra_javascript": [
            "javascripts/focus.js"  # Script pour le mode "Focus" (plein écran)
        ],
        "extra_css": [
            "stylesheets/focus.css"
        ]
    },

    # -------------------------------------------------------------------------
    # Pied de page (Footer)
    # -------------------------------------------------------------------------
    "footer": (
        "{% block footer %}\n"
        "  <div class=\"md-footer-meta md-typeset\">\n"
        "    <div class=\"md-footer-meta__inner\">\n\n"
        "      <div>\n"
        "        <a href=\"https://tahe.developpez.com\" target=\"_blank\">\n"
        "          https://tahe.developpez.com\n"
        "        </a>\n"
        "        <br>\n"
        "        Ce cours-tutoriel écrit par <strong>Serge Tahé</strong> est mis à disposition du public selon les termes de la\n"
        "        <em>Licence Creative Commons Attribution – Pas d’Utilisation Commerciale –\n"
        "        Partage dans les Mêmes Conditions 3.0 non transposé</em>.\n"
        "      </div>\n\n"
        "    </div>\n"
        "  </div>\n"
        "{% endblock %}"
    ),

    # -------------------------------------------------------------------------
    # Configuration supplémentaire (Analytics, etc.)
    # -------------------------------------------------------------------------
    "extra": {
        "analytics": {
            "provider": "google",
            "property": "G-EBZC3JVJNR"
        }
    },

    # -------------------------------------------------------------------------
    # Détection du Titre du Document
    # -------------------------------------------------------------------------
    "document_title": {
        # Styles ODT à considérer comme le titre principal du document (H1 global)
        "style_names": [
            "P1"
        ],
        # CSS appliqué à ce titre dans le Markdown généré
        "css": "font-size: 28px; font-weight: bold; margin-bottom: 1em; line-height: 1.2; color: #2c3e50;"
    },

    # -------------------------------------------------------------------------
    # Gestion du Code Source
    # -------------------------------------------------------------------------
    "code": {
        # Mot-clé dans le style ODT pour identifier un bloc de code
        "style_keywords": [
            "code"
        ],
        # Langage par défaut si aucune détection ne fonctionne
        "default_language": "text",

        # Style visuel du code enrichi (gras/italique/couleur préservés depuis ODT)
        "rich_line_height": "12px",
        "rich_font_family": "Consolas, 'Courier New', monospace",
        "rich_font_size": "15px",

        # Règles de détection automatique du langage basé sur le contenu
        "detection_rules": {
            "csharp": [
                "using", "Console.WriteLine", "public static void Main", "WebMethod",
                "TryParse", "EventArgs", "String.Format", "System.Web.Services"
            ],
            "java": [
                "System.out.println", "public static void main(String", "package",
                "JUnitTest", "Class.forName", "PreparedStatement", "private static void",
                "private void", "getAgendaMedecinJour", "@PostConstruct", "@ResponseBody",
                "@RequestMapping", "getMedecin", "@Entity", "@Autowired", "@Bean",
                "Serializable", "getClient", "getCreneau", "getRv", "PostAjouterRv",
                "PostSupprimerRv", "@EnableJpaRepositories", "@Component", "getAgendaMedecinJour",
                "getResponse", "getMessagesForException", "getBase64", "ajouterRv",
                "Reponse", "getPartialViewAgenda", "setModelforAgenda", "ActionContext",
                "getActionContext", "PostLang", "PostUser", "PostGetAgenda", "@NotNull",
                "@EnableAutoConfiguration", "HttpSecurity"
            ],
            "html": [
                "<html>", "</div>", "<body>", "<script>", "href=", "<span>", "<p>",
                "<h2>", "<form", "<table", "<input"
            ],
            "sql": [
                "SELECT", "INSERT INTO", "UPDATE", "DELETE FROM", "WHERE",
                "CREATE TABLE", "AlTER TABLE"
            ],
            "python": [
                "def", "import", "print(", "from"
            ],
            "xml": [
                "<?xml", "<project", "<version>", "<configuration>", "<build>",
                "<dependency>", "<properties>", "<configuration>", "<start-class>"
            ],
            "javascript": [
                "use strict", "console.log", "let", "constructor", "async", "export"
            ],
            "php": [
                "<?php", "declare", "require"
            ],
            "vbscript": [
                "Option", "Dim", "Explicit"
            ],
            "markdown": [
                "# ", "## ", "### ", "**", "__", "![", "]("  # Mots-clés typiques du Markdown
            ],
        },
        # ---------------------------------------------------------------------
        # Bouton [Copier] dans les blocs de code (copie dans le presse-papier)
        # ---------------------------------------------------------------------

        # Active/désactive l'ajout du bouton [Copier] (True = activé)
        "copy_button": True,

        # Libellé du bouton avant copie
        "copy_label": "Copier",

        # Libellé temporaire après une copie réussie
        "copy_copied_label": "Copié",

        # Si True, le bouton n'apparaît que si le langage du bloc est "reconnu"
        # (par ex. language-java / language-python, etc.)
        "copy_only_recognized_language": True,

        # Seuil minimum de lignes pour afficher le bouton :
        # - 0  => pas de seuil (tous les blocs "langage reconnu" auront le bouton)
        # - >0 => le bloc doit avoir au moins ce nombre de lignes
        "copy_min_lines": 0,

        # Si True, on autorise aussi le bouton sur les blocs Pygments "colorés"
        # même si la classe language-xxx n'est pas explicitement présente.
        # Utile pour certains rendus de code (highlighttable) où la coloration existe
        # mais où le langage n'apparaît pas dans une classe CSS.
        "copy_allow_pygments_heuristic": True,

        # Apparence du bouton [Copier] (CSS inline : uniquement des déclarations,
        # sans accolades). Permet de personnaliser facilement le look.
        # ---------------------------------------------------------------------
        # Style "Material-like" pour le bouton [Copier]
        # (CSS inline : uniquement des déclarations, sans accolades)
        # ---------------------------------------------------------------------
        "copy_style": {
            # Conteneur du bloc de code : nécessaire pour positionner le bouton
            "container": "position: relative;",

            # Style normal du bouton
            "btn": (
                "position:absolute; top:.5rem; right:.5rem; "
                "display:inline-flex; align-items:center; justify-content:center; "
                "gap:.35rem; "
                "padding:.25rem .6rem; "
                "font-size:.72rem; font-weight:600; letter-spacing:.01em; "
                "line-height:1.2; "
                "border-radius:999px; "
                "border:1px solid rgba(0,150,136,.45); "
                "background:rgba(0,150,136,.12); "
                "color:rgb(0,150,136); "
                "box-shadow:0 1px 2px rgba(0,0,0,.10); "
                "backdrop-filter:saturate(180%) blur(6px); "
                "cursor:pointer; user-select:none; "
                "transition:transform .08s ease, box-shadow .12s ease, background .12s ease;"
                "z-index:5;"
            ),

            # Survol : un peu plus “élevé” (comme Material)
            "btn_hover": (
                "background:rgba(0,150,136,.20); "
                "box-shadow:0 3px 10px rgba(0,0,0,.18); "
                "transform:translateY(-1px);"
            ),

            # État “copié” : léger fade
            "btn_copied": "opacity:.85;"
        },
    },

    # -------------------------------------------------------------------------
    # Images : paramètres d'ombre (zoom / lightbox)
    # -------------------------------------------------------------------------
    "images": {
        "shadow": {
            # Active/désactive l'ombre autour des images
            "enabled": True,

            # Rayon d'arrondi appliqué aux images (ex: "0px", "4px", "8px", ...)
            "border_radius": "8px",

            # Ombre par défaut sur les images "zoomables"
            "zoomable": "0 8px 24px rgba(0,0,0,.28), 0 18px 60px rgba(0,0,0,.20)",

            # Ombre au survol (hover) des images "zoomables"
            "zoomable_hover": "0 12px 30px rgba(0,0,0,.32), 0 26px 80px rgba(0,0,0,.22)",

            # Ombre lorsque l'image est affichée en grand (lightbox)
            "lightbox": "0 24px 80px rgba(0,0,0,.65)",
        }
    },

    # -------------------------------------------------------------------------
    # Fichiers statiques à copier à la racine du site
    # -------------------------------------------------------------------------
    "files_to_copy": [
        "google5179c0eaff293e02.html",
        "robots.txt",
        "word-odt-vers-html-janv-2026.pdf",
        "word-odt-vers-html-janv-2026.zip"
    ],

    # Mode debug : affiche les styles rencontrés avant le premier titre
    "debug": True
}
