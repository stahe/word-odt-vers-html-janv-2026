import sys
import subprocess
import os
import webbrowser
from mkdocs.commands.build import build
from mkdocs.config import load_config


def build_site():
    print("Démarrage de la construction du site MkDocs...")

    if not os.path.exists("mkdocs.yml"):
        print("Erreur : mkdocs.yml introuvable. Lancez d'abord convert.py.")
        return

    try:
        # Build via le module python
        cfg = load_config("mkdocs.yml")
        build(cfg)

        site_dir = cfg['site_dir']
        print(f"Construction réussie ! Le site est dans : {site_dir}")

        # Ouverture dans le navigateur
        index_path = os.path.abspath(os.path.join(site_dir, "index.html"))
        if os.path.exists(index_path):
            print(f"Ouverture de {index_path} dans le navigateur...")
            webbrowser.open(f"file://{index_path}")
        else:
            print("Erreur : Impossible de trouver index.html pour l'ouvrir.")

    except Exception as e:
        print(f"Erreur durant le build : {e}")


if __name__ == "__main__":
    build_site()