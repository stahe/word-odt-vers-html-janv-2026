#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""convert_docx_v16.py

DOCX -> MkDocs converter (Word2HTML project)
Version: V16

V4 additions (vs previous working V3 behavior):
  - --audit : analyze the DOCX without generating a full site; outputs audit.json (+ optional audit.txt).
  - --max-h1 N : generate only the first N level-1 headings/pages (quick smoke test on large docs).
  - report.txt : end-of-run anomaly report (unsupported objects, missing relationships, list fallbacks, etc.).

Core goals preserved:
  - Convert .docx directly to MkDocs structure (no LibreOffice / ODT).
  - Robust multi-level lists (numbering.xml) + fallback lists by paragraph style name.
  - Heading "rebasing" if the document starts at Heading2/Titre2 (no Heading1 present).
  - Extract inline and floating images (wp:inline and wp:anchor) referenced via rId.

Usage:
  python convert_docx_v16.py <file.docx> <config.py|config.json> [--audit] [--max-h1 N]
"""

import sys
import os
import re
import json
import html
import shutil
import zipfile
import importlib.util
import argparse
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from unidecode import unidecode

try:
    from lxml import etree
except Exception as e:
    raise SystemExit("Erreur: lxml est requis (pip install lxml).") from e


VERSION = "V16"


# -------------------------
# Namespaces
# -------------------------

NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
    "pic": "http://schemas.openxmlformats.org/drawingml/2006/picture",
    "v": "urn:schemas-microsoft-com:vml",
    "o": "urn:schemas-microsoft-com:office:office",
}


# -------------------------
# Config (compatible with convert.py)
# -------------------------

def load_configuration(config_path: str) -> dict:
    default_config = {
        "mkdocs": {
            "site_name": "Documentation",
            "site_url": "",
            "repo_url": "",
            "repo_name": "GitHub",
            "use_directory_urls": False,
        },
        "footer": "<footer>Pied de page</footer>",
        "code": {
            "style_keywords": ["code", "consolas", "source"],
            "default_language": "text",
            "detection_rules": {},
            "rich_line_height": "theme",
            "rich_font_family": "theme",
            "rich_font_size": "theme",
        },
        "document_title": {
            "style_names": ["Title", "Titre", "Titre principal"],
            "css": "font-size: 28px; font-weight: bold; margin-bottom: 1em;",
        },
        "debug": False,
        "files_to_copy": [],
        "extra": {},
    }

    if not config_path or not os.path.exists(config_path):
        return default_config

    user_config: dict = {}
    try:
        if config_path.endswith(".py"):
            spec = importlib.util.spec_from_file_location("user_config_module", config_path)
            module = importlib.util.module_from_spec(spec)
            assert spec.loader is not None
            spec.loader.exec_module(module)
            if hasattr(module, "config") and isinstance(module.config, dict):
                user_config = module.config
        else:
            with open(config_path, "r", encoding="utf-8") as f:
                user_config = json.load(f)
    except Exception as e:
        print(f"[WARN] Erreur lors du chargement de la config: {e}. Utilisation des défauts.")

    # Merge
    if "mkdocs" in user_config:
        default_config["mkdocs"].update(user_config["mkdocs"])
        exts = default_config["mkdocs"].get(
            "markdown_extensions", user_config["mkdocs"].get("markdown_extensions", [])
        )
        if isinstance(exts, list):
            def has_ext(name: str) -> bool:
                for x in exts:
                    if x == name:
                        return True
                    if isinstance(x, dict) and name in x:
                        return True
                return False

            if not has_ext("md_in_html"):
                exts.append("md_in_html")
            if not has_ext("footnotes"):
                exts.append("footnotes")
        default_config["mkdocs"]["markdown_extensions"] = exts

    for k in ("footer", "code", "document_title", "debug", "files_to_copy", "extra"):
        if k in user_config:
            if isinstance(default_config.get(k), dict) and isinstance(user_config[k], dict):
                default_config[k].update(user_config[k])
            else:
                default_config[k] = user_config[k]

    return default_config


def create_directory(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def sanitize_anchor_id(text_: str) -> str:
    if not text_:
        return ""
    return re.sub(r"[^a-z0-9\-]", "", unidecode(str(text_)).lower().replace(" ", "-"))


def generate_safe_filename(raw_title: str) -> str:
    base = re.sub(r"[^a-z0-9\-]", "", unidecode(raw_title.lower().replace(" ", "-")))
    return (base or "page") + ".md"


def escape_markdown_text(s: str) -> str:
    if s is None:
        return ""
    s = s.replace("\\", "\\\\")
    s = s.replace("*", "\\*").replace("_", "\\_")
    return s


def escape_text_for_md_display(s: str) -> str:
    """Escape plain text for safe display inside a Markdown page.

    Rationale: A DOCX paragraph can contain expressions like `a*b` where `*`
    would be interpreted by Markdown as emphasis and disappear.

    We mainly emit inline HTML for formatting; for unformatted text we still
    concatenate raw text segments. To prevent Markdown from re-interpreting the
    content, we encode Markdown-sensitive characters as HTML entities.

    This is applied only to *plain text segments* (not code blocks).
    """
    if s is None:
        return ""
    # First escape HTML special chars
    out = html.escape(str(s))
    # Then neutralize Markdown metacharacters in plain text.
    out = (out
           .replace("*", "&#42;")
           .replace("_", "&#95;")
           .replace("[", "&#91;")
           .replace("]", "&#93;")
           .replace("`", "&#96;"))
    return out


# -------------------------
# Footnotes (DOCX)
# -------------------------

def init_footnotes_ctx():
    return {"counter": 0, "defs": [], "seen": set(), "docx_id_to_fid": {}}

def register_docx_footnote(footnotes_ctx, docx_id: str, body_text: str) -> str:
    """Register a DOCX footnote id -> MkDocs footnote id, storing definition once per page."""
    if footnotes_ctx is None:
        return ""
    docx_id = str(docx_id)
    if docx_id in footnotes_ctx["docx_id_to_fid"]:
        return footnotes_ctx["docx_id_to_fid"][docx_id]
    footnotes_ctx["counter"] += 1
    fid = f"fn{footnotes_ctx['counter']}"
    footnotes_ctx["docx_id_to_fid"][docx_id] = fid
    if fid in footnotes_ctx["seen"]:
        return fid
    footnotes_ctx["seen"].add(fid)
    body = (body_text or "").strip()
    footnotes_ctx["defs"].append((fid, body))
    return fid

def write_footnotes(current_file, footnotes_ctx):
    if not footnotes_ctx:
        return
    defs = footnotes_ctx.get("defs") or []
    if not defs:
        return
    current_file.write("\n\n---\n\n")
    for fid, body in defs:
        body = (body or "").strip()
        lines = body.splitlines() if body else [""]
        current_file.write(f"[^%s]: %s\n" % (fid, lines[0] if lines else ""))
        for ln in lines[1:]:
            current_file.write(f"    {ln}\n")


# -------------------------
# Code detection (same idea as convert.py)
# -------------------------

def detect_language(code_content: str, code_config: dict) -> str:
    if not code_content:
        return code_config.get("default_language", "text")
    content_stripped = code_content.strip()
    if content_stripped.startswith("<?php"):
        return "php"
    if content_stripped.startswith("<?xml"):
        return "xml"
    rules = code_config.get("detection_rules", {}) or {}
    scores: Dict[str, int] = {}
    for lang, keywords in rules.items():
        if not keywords:
            continue
        count = sum(1 for k in keywords if k in code_content)
        if count:
            scores[lang] = count
    if scores:
        return max(scores, key=scores.get)
    if "function" in code_content or "var " in code_content:
        return "javascript"
    return code_config.get("default_language", "text")


def get_fence(content: str) -> str:
    matches = re.findall(r"`+", content or "")
    longest = max((len(m) for m in matches), default=0)
    return "`" * max(3, longest + 1)


def is_code_paragraph_by_style(style_id: Optional[str], code_cfg: dict) -> bool:
    if not style_id:
        return False
    kws = [unidecode(s).lower() for s in (code_cfg.get("style_keywords") or [])]
    s = unidecode(style_id).lower()
    return any(k in s for k in kws)


# -------------------------
# Rich code (DOCX) helpers
# -------------------------

_HIGHLIGHT_TO_CSS = {
    "yellow": "#fff59d",
    "green": "#c8e6c9",
    "cyan": "#b2ebf2",
    "magenta": "#f8bbd0",
    "blue": "#bbdefb",
    "red": "#ffcdd2",
    "darkBlue": "#90caf9",
    "darkRed": "#ef9a9a",
    "darkYellow": "#fff176",
    "darkGreen": "#a5d6a7",
    "lightGray": "#eeeeee",
    "darkGray": "#bdbdbd",
    "black": "#000000",
    "white": "#ffffff",
}

def _emu_to_px(emu: int) -> int:
    # Word uses EMU: 914400 EMU per inch. Assume 96 dpi for CSS px.
    try:
        return max(1, int(round(int(emu) / 9525)))
    except Exception:
        return 0

def _run_style_css(r) -> str:
    """Inline CSS capturing run-level formatting (bold/italic/underline/color/highlight/shading)."""
    rpr = r.find("./w:rPr", namespaces=NS)
    if rpr is None:
        return ""
    css = []

    if rpr.find("./w:b", namespaces=NS) is not None:
        css.append("font-weight:bold")
    if rpr.find("./w:i", namespaces=NS) is not None:
        css.append("font-style:italic")

    u = rpr.find("./w:u", namespaces=NS)
    if u is not None:
        uval = u.get(etree.QName(NS["w"], "val"))
        if not uval or str(uval).lower() != "none":
            css.append("text-decoration:underline")

    col = rpr.find("./w:color", namespaces=NS)
    if col is not None:
        v = col.get(etree.QName(NS["w"], "val"))
        if v and str(v).lower() not in ("auto",):
            vv = str(v).strip()
            if re.fullmatch(r"[0-9a-fA-F]{6}", vv):
                css.append(f"color:#{vv}")

    # Highlight (w:highlight uses named colors) + Shading (w:shd fill uses hex)
    bg = None
    hi = rpr.find("./w:highlight", namespaces=NS)
    if hi is not None:
        v = hi.get(etree.QName(NS["w"], "val"))
        if v:
            vv = str(v).strip()
            bg = _HIGHLIGHT_TO_CSS.get(vv, None)
            if not bg and re.fullmatch(r"[0-9a-fA-F]{6}", vv):
                bg = "#" + vv

    if not bg:
        shd = rpr.find("./w:shd", namespaces=NS)
        if shd is not None:
            fill = shd.get(etree.QName(NS["w"], "fill"))
            if fill:
                ff = str(fill).strip()
                if re.fullmatch(r"[0-9a-fA-F]{6}", ff):
                    bg = "#" + ff

    if bg:
        css.append(f"background-color:{bg}")

    return ";".join(css)

def paragraph_has_rich_code_formatting(p) -> bool:
    """True if paragraph contains run-level formatting we should preserve."""
    for r in p.findall(".//w:r", namespaces=NS):
        if _run_style_css(r):
            return True
    return False

def runs_to_rich_code_html_line(p) -> str:
    """Render a paragraph as an HTML line preserving run styling."""
    parts: List[str] = []
    # iterate in-document order for runs/hyperlinks
    for node in p:
        tag = etree.QName(node).localname
        if tag == "r":
            css = _run_style_css(node)
            t = _run_text_preserve(node) or ""
            t = html.escape(t)
            if css:
                parts.append(f'<span style="{css}">{t}</span>')
            else:
                parts.append(t)
        elif tag == "hyperlink":
            t = _run_text_preserve(node) or ""
            parts.append(html.escape(t))
        elif tag == "br":
            parts.append("<br>")
        else:
            t = _run_text_preserve(node) or ""
            if t:
                parts.append(html.escape(t))
    return "".join(parts)

def render_rich_code_block(lines_html: List[str], lang: str, start_line: int = 1, show_linenums: bool = False) -> str:
    lang_class = f"language-{lang}" if lang else "language-text"
    start = int(start_line) if start_line and int(start_line) > 0 else 1
    counter_reset = start - 1
    linenums_attr = "true" if show_linenums else "false"
    wrapped = "\n".join(f'<span class="docx-code-line">{ln}</span>' for ln in lines_html)
    return (
        f'<div class="docx-code-rich" data-linenums="{linenums_attr}" '
        f'style="counter-reset: docxline {counter_reset};">'
        f'<pre><code class="{lang_class}">\n{wrapped}\n</code></pre></div>'
    )



# -------------------------
# Numbering model
# -------------------------

@dataclass
class LevelDef:
    num_fmt: str = "bullet"   # decimal, bullet, lowerLetter, upperRoman, ...
    start: int = 1


@dataclass
class Numbering:
    numId_to_abs: Dict[str, str]
    abs_levels: Dict[str, Dict[int, LevelDef]]


def _zip_read_text(z: zipfile.ZipFile, path: str) -> Optional[bytes]:
    try:
        return z.read(path)
    except KeyError:
        return None


def parse_numbering(z: zipfile.ZipFile) -> Numbering:
    xml = _zip_read_text(z, "word/numbering.xml")
    if not xml:
        return Numbering(numId_to_abs={}, abs_levels={})
    root = etree.fromstring(xml)

    abs_levels: Dict[str, Dict[int, LevelDef]] = {}
    for absnum in root.findall(".//w:abstractNum", namespaces=NS):
        abs_id = absnum.get(etree.QName(NS["w"], "abstractNumId"))
        if not abs_id:
            continue
        levels: Dict[int, LevelDef] = {}
        for lvl in absnum.findall("./w:lvl", namespaces=NS):
            ilvl = lvl.get(etree.QName(NS["w"], "ilvl"))
            if ilvl is None:
                continue
            try:
                i = int(ilvl)
            except Exception:
                continue
            numfmt = lvl.find("./w:numFmt", namespaces=NS)
            fmt = (numfmt.get(etree.QName(NS["w"], "val")) if numfmt is not None else None) or "bullet"
            start = 1
            start_el = lvl.find("./w:start", namespaces=NS)
            if start_el is not None:
                try:
                    start = int(start_el.get(etree.QName(NS["w"], "val")) or "1")
                except Exception:
                    start = 1
            levels[i] = LevelDef(num_fmt=fmt, start=start)
        abs_levels[str(abs_id)] = levels

    numId_to_abs: Dict[str, str] = {}
    for num in root.findall(".//w:num", namespaces=NS):
        numId = num.get(etree.QName(NS["w"], "numId"))
        abs_el = num.find("./w:abstractNumId", namespaces=NS)
        abs_id = abs_el.get(etree.QName(NS["w"], "val")) if abs_el is not None else None
        if numId and abs_id:
            numId_to_abs[str(numId)] = str(abs_id)
    return Numbering(numId_to_abs=numId_to_abs, abs_levels=abs_levels)


# -------------------------
# Relationships & media
# -------------------------

def parse_relationships(z: zipfile.ZipFile) -> Dict[str, str]:
    xml = _zip_read_text(z, "word/_rels/document.xml.rels")
    if not xml:
        return {}
    root = etree.fromstring(xml)
    out: Dict[str, str] = {}
    for rel in root.findall(".//{*}Relationship"):
        rid = rel.get("Id")
        target = rel.get("Target")
        if rid and target:
            out[rid] = target
    return out



def parse_footnotes_db(z: zipfile.ZipFile) -> Dict[str, str]:
    """Parse word/footnotes.xml into {docx_footnote_id: plain_text}.

    Note: python-docx does not expose footnotes reliably, so we read XML directly.
    We keep plain text (with line breaks) for MkDocs footnote definitions.
    """
    xml = _zip_read_text(z, "word/footnotes.xml")
    if not xml:
        return {}
    root = etree.fromstring(xml)
    out: Dict[str, str] = {}
    for fn in root.findall(".//w:footnote", namespaces=NS):
        fid = fn.get(etree.QName(NS["w"], "id"))
        if fid is None:
            continue
        try:
            if int(fid) <= 0:
                continue  # skip separators
        except Exception:
            continue
        # Collect displayed text from paragraphs
        parts: List[str] = []
        for p in fn.findall(".//w:p", namespaces=NS):
            t = (etree.tostring(p, method="text", encoding="unicode") or "").strip()
            if t:
                parts.append(t)
        out[str(fid)] = "\n".join(parts).strip()
    return out

def extract_media(z: zipfile.ZipFile, images_dir: str) -> Dict[str, str]:
    """Extract word/media/* into docs/images and return map docx_path->site_relative_src."""
    create_directory(images_dir)
    media_map: Dict[str, str] = {}
    for info in z.infolist():
        if info.filename.startswith("word/media/") and not info.is_dir():
            base = os.path.basename(info.filename)
            safe = re.sub(r"[^a-zA-Z0-9._-]", "_", base)
            target_path = os.path.join(images_dir, safe)
            with open(target_path, "wb") as f:
                f.write(z.read(info))
            media_map[info.filename] = f"images/{safe}"
    return media_map


# -------------------------
# DOCX paragraph helpers
# -------------------------

def _p_style(p) -> Optional[str]:
    pPr = p.find("./w:pPr", namespaces=NS)
    if pPr is None:
        return None
    pStyle = pPr.find("./w:pStyle", namespaces=NS)
    if pStyle is None:
        return None
    return pStyle.get(etree.QName(NS["w"], "val"))


def _outline_level(p) -> Optional[int]:
    pPr = p.find("./w:pPr", namespaces=NS)
    if pPr is None:
        return None
    ol = pPr.find("./w:outlineLvl", namespaces=NS)
    if ol is None:
        return None
    try:
        return int(ol.get(etree.QName(NS["w"], "val")) or "0") + 1
    except Exception:
        return None


def _heading_from_style(style_id: Optional[str]) -> Optional[int]:
    if not style_id:
        return None
    s = unidecode(style_id).lower()
    # Word built-ins: Heading1..Heading9
    m = re.match(r"heading\s*([1-9])$", s)
    if m:
        return int(m.group(1))
    # French/LO-ish styles: Titre1 / Titre 1 / Titre2
    m = re.match(r"titre\s*([1-9])$", s)
    if m:
        return int(m.group(1))
    # Generic: H1, H2
    m = re.match(r"h\s*([1-9])$", s)
    if m:
        return int(m.group(1))
    return None


def _p_num_info(p) -> Tuple[Optional[int], Optional[int]]:
    pPr = p.find("./w:pPr", namespaces=NS)
    if pPr is None:
        return None, None
    numPr = pPr.find("./w:numPr", namespaces=NS)
    if numPr is None:
        return None, None
    numId_el = numPr.find("./w:numId", namespaces=NS)
    ilvl_el = numPr.find("./w:ilvl", namespaces=NS)
    numId = numId_el.get(etree.QName(NS["w"], "val")) if numId_el is not None else None
    ilvl = ilvl_el.get(etree.QName(NS["w"], "val")) if ilvl_el is not None else None
    try:
        return (int(numId) if numId is not None else None), (int(ilvl) if ilvl is not None else None)
    except Exception:
        return None, None



def _p_text_preserve(p) -> str:
    """Extract paragraph text preserving spaces and tabs (critical for code blocks)."""
    out: List[str] = []
    for node in p.iter():
        if not isinstance(node.tag, str):
            continue
        tag = etree.QName(node).localname
        if tag == "t":
            out.append(node.text or "")
        elif tag == "tab":
            out.append("\t")
        elif tag in ("br", "cr"):
            out.append("\n")
    return "".join(out)


def _run_text_preserve(r) -> str:
    """Extract run text preserving spaces and tabs."""
    out: List[str] = []
    for node in r.iter():
        if not isinstance(node.tag, str):
            continue
        tag = etree.QName(node).localname
        if tag == "t":
            out.append(node.text or "")
        elif tag == "tab":
            out.append("\t")
        elif tag in ("br", "cr"):
            out.append("\n")
    return "".join(out)

def _p_borders_css(p) -> Tuple[Optional[str], Optional[str]]:
    """Return (border_top_css, border_bottom_css) for paragraph, if any.

    Word stores borders in w:pPr/w:pBdr/(w:top,w:bottom) with attributes:
      - w:val (single, double, etc.)  -> we map most to 'solid'
      - w:sz  (eighths of a point)
      - w:color (hex or 'auto')
    """
    pPr = p.find("./w:pPr", namespaces=NS)
    if pPr is None:
        return (None, None)
    bdr = pPr.find("./w:pBdr", namespaces=NS)
    if bdr is None:
        return (None, None)

    def _one(side: str) -> Optional[str]:
        el = bdr.find(f"./w:{side}", namespaces=NS)
        if el is None:
            return None
        val = (el.get(etree.QName(NS["w"], "val")) or "").lower()
        if val in ("nil", "none", "0"):
            return None
        sz = el.get(etree.QName(NS["w"], "sz"))
        color = el.get(etree.QName(NS["w"], "color")) or "000000"
        if str(color).lower() == "auto":
            color = "000000"
        try:
            # w:sz is in 1/8 pt
            pt = (int(sz) / 8.0) if sz is not None else 1.0
        except Exception:
            pt = 1.0
        style = "solid"
        return f"{pt:.2f}pt {style} #{color}"

    return (_one("top"), _one("bottom"))



def _p_plain_text(p) -> str:
    return (etree.tostring(p, method="text", encoding="unicode") or "").strip()


def _html_wrap(txt: str, *, bold: bool = False, italic: bool = False, underline: bool = False,
               color_hex: Optional[str] = None, highlight_css: Optional[str] = None,
               wrap_plain_in_span: bool = False) -> str:
    """Apply run-level formatting using HTML tags.

    We intentionally prefer HTML over Markdown for inline styling to avoid
    Markdown eating characters (e.g., '*' in arithmetic expressions).
    When wrap_plain_in_span=True and the run has no explicit styling, we wrap the
    escaped text in a <span> to prevent Markdown from re-interpreting it.
    """
    if txt is None:
        txt = ""

    # For plain text runs we must neutralize Markdown metacharacters (e.g. '*', '_', '[', ']', '`')
    # because those would otherwise be parsed by Markdown.
    if wrap_plain_in_span and (not bold) and (not italic) and (not underline) and (not color_hex) and (not highlight_css):
        base = escape_text_for_md_display(txt)
        return f"<span>{base}</span>"

    # Styled runs are emitted as HTML. We still neutralize Markdown metacharacters
    # because some Markdown configurations may parse inside inline HTML.
    s = html.escape(str(txt))
    s = (s.replace('*','&#42;').replace('_','&#95;').replace('[','&#91;').replace(']','&#93;').replace('`','&#96;'))

    if underline:
        s = f"<u>{s}</u>"
    if italic:
        s = f"<i>{s}</i>"
    if bold:
        s = f"<b>{s}</b>"
    if color_hex:
        s = f'<span style="color:{color_hex}">{s}</span>'
    if highlight_css:
        s = f'<mark style="background-color:{highlight_css}">{s}</mark>'

    return s
def _fix_literal_backslash_newlines(s: str) -> str:
    """Convert visible literal \\n sequences into real newlines.

    Some DOCX content may contain the two-character sequence '\\n' (and '\\r\\n')
    where actual paragraph breaks were intended. If left as-is, browsers display
    the backslashes instead of breaking lines/paragraphs.

    This normalization is only applied to non-code text contexts.
    """
    if not s:
        return ""
    # Convert visible Windows-style first
    s = s.replace('\\r\\n', '\n')
    # Then visible 

    s = s.replace('\\n', '\n')
    return s

def _run_to_inline_html(r, footnotes_ctx=None, footnotes_db=None, wrap_plain_in_span: bool = False) -> str:
    """Render one <w:r> (run) to inline HTML with formatting + links + footnotes."""
    # Footnote reference
    fnr = r.find("./w:footnoteReference", namespaces=NS)
    if fnr is not None:
        fn_id = fnr.get(etree.QName(NS["w"], "id"))
        if fn_id is None:
            return ""
        body = ""
        if isinstance(footnotes_db, dict):
            body = footnotes_db.get(str(fn_id), "") or ""
        fid = register_docx_footnote(footnotes_ctx, str(fn_id), body)
        return f"[^{fid}]" if fid else ""

    rPr = r.find("./w:rPr", namespaces=NS)
    bold = bool(rPr is not None and rPr.find("./w:b", namespaces=NS) is not None)
    italic = bool(rPr is not None and rPr.find("./w:i", namespaces=NS) is not None)

    underline = False
    if rPr is not None:
        u = rPr.find("./w:u", namespaces=NS)
        if u is not None:
            uval = u.get(etree.QName(NS["w"], "val"))
            underline = (not uval) or (str(uval).lower() != "none")

    color_hex = None
    if rPr is not None:
        col = rPr.find("./w:color", namespaces=NS)
        if col is not None:
            v = col.get(etree.QName(NS["w"], "val"))
            if v and str(v).lower() not in ("auto",):
                vv = str(v).strip()
                if re.fullmatch(r"[0-9a-fA-F]{6}", vv):
                    color_hex = "#" + vv

    # Highlight: w:highlight (named) or w:shd fill (hex)
    highlight_css = None
    if rPr is not None:
        hi = rPr.find("./w:highlight", namespaces=NS)
        if hi is not None:
            v = hi.get(etree.QName(NS["w"], "val"))
            if v:
                vv = str(v).strip()
                highlight_css = _HIGHLIGHT_TO_CSS.get(vv, None)
                if (not highlight_css) and re.fullmatch(r"[0-9a-fA-F]{6}", vv):
                    highlight_css = "#" + vv

        if not highlight_css:
            shd = rPr.find("./w:shd", namespaces=NS)
            if shd is not None:
                fill = shd.get(etree.QName(NS["w"], "fill"))
                if fill:
                    ff = str(fill).strip()
                    if re.fullmatch(r"[0-9a-fA-F]{6}", ff):
                        highlight_css = "#" + ff

    # text nodes
    t_nodes = r.findall("./w:t", namespaces=NS)
    if t_nodes:
        txt = "".join((t.text or "") for t in t_nodes)
        return _html_wrap(txt, bold=bold, italic=italic, underline=underline, color_hex=color_hex, highlight_css=highlight_css, wrap_plain_in_span=wrap_plain_in_span)

    # tabs / breaks
    if r.find("./w:tab", namespaces=NS) is not None:
        return "&nbsp;&nbsp;&nbsp;&nbsp;"
    if r.find("./w:br", namespaces=NS) is not None:
        return "<br>"
    if r.find("./w:cr", namespaces=NS) is not None:
        return "<br>"

    instr = r.findall("./w:instrText", namespaces=NS)
    if instr:
        txt = "".join((t.text or "") for t in instr)
        return _html_wrap(txt, bold=bold, italic=italic, underline=underline, color_hex=color_hex, highlight_css=highlight_css, wrap_plain_in_span=wrap_plain_in_span)

    return ""

def _render_hyperlink_inline(h, rels: Dict[str, str], targets_map: Dict[str, str], current_filename: str, footnotes_ctx=None, footnotes_db=None) -> str:
    """Render <w:hyperlink> to <a href=...>...</a>.

    Supports:
      - external links via r:id (document.xml.rels)
      - internal links via w:anchor (bookmarks)
    """
    rid = h.get(etree.QName(NS["r"], "id"))
    anchor = h.get(etree.QName(NS["w"], "anchor"))
    href = None

    if rid and rid in rels:
        href = rels[rid]
        # normalize typical docx rel target
        if href.startswith("../"):
            href = href[3:]
    elif anchor:
        anchor_id = sanitize_anchor_id(anchor)
        target_file = targets_map.get(anchor)
        if target_file and target_file != current_filename:
            href = f"{target_file}#{anchor_id}"
        else:
            href = f"#{anchor_id}"

    inner_parts: List[str] = []
    for node in h:
        lname = etree.QName(node).localname
        if lname == "r":
            inner_parts.append(_run_to_inline_html(node, footnotes_ctx, footnotes_db))
        elif lname == "fldSimple":
            inner_parts.append(_p_plain_text(node))
        else:
            # best-effort
            inner_parts.append(html.escape(etree.tostring(node, method="text", encoding="unicode") or ""))
    inner = "".join(inner_parts).strip()

    if not href:
        return inner  # fallback: keep visible text
    return f'<a href="{html.escape(href, quote=True)}">{inner}</a>'


def paragraph_to_inline_html(p, rels: Dict[str, str], targets_map: Dict[str, str], current_filename: str, footnotes_ctx=None, footnotes_db=None) -> str:
    """Render a Word paragraph (<w:p>) to inline HTML with:
      - bold/italic/underline
      - highlight + font color
      - hyperlinks (external + internal bookmarks)
      - bookmark anchors (<a id=...></a>)
      - field-code cross refs (REF/PAGEREF/HYPERLINK)
      - footnote refs (w:footnoteReference)
      - line breaks/tabs

    Important: To avoid Markdown interpreting characters like '*' in plain text,
    we wrap text segments in <span>...</span> and escape HTML safely.
    """

    def _span_txt(s: str) -> str:
        # escape_text_for_md_display already HTML-escapes and neutralizes MD meta chars
        return f"<span>{escape_text_for_md_display(s)}</span>"

    parts: List[str] = []

    # Complex field state machine
    in_field = False
    instr_buf: List[str] = []
    in_result = False
    result_buf: List[str] = []

    def _flush_field():
        nonlocal in_field, instr_buf, in_result, result_buf
        if not in_field:
            return
        instr = " ".join(instr_buf).strip()
        href = _href_from_field_instr(instr, rels, targets_map, current_filename)
        body = "".join(result_buf).strip()
        if href and body:
            parts.append(f'<a href="{html.escape(href, quote=True)}">{body}</a>')
        else:
            # If we can't resolve, fall back to the rendered result (or nothing)
            if body:
                parts.append(body)
        in_field = False
        in_result = False
        instr_buf = []
        result_buf = []

    # Iterate direct children of <w:p>
    for child in list(p):
        tag = etree.QName(child).localname

        # Bookmarks
        if tag == "bookmarkStart":
            name = child.get(f"{{{NS['w']}}}name")
            if name:
                parts.append(f'<a id="{sanitize_anchor_id(name)}"></a>')
            continue
        if tag == "bookmarkEnd":
            continue

        # Simple fields (w:fldSimple instr="...")
        if tag == "fldSimple":
            instr = child.get(f"{{{NS['w']}}}instr") or ""
            href = _href_from_field_instr(instr, rels, targets_map, current_filename)
            # fldSimple content is the visible result
            inner_parts: List[str] = []
            for r in child.findall(".//w:r", namespaces=NS):
                inner_parts.append(_run_to_inline_html(r, footnotes_ctx, footnotes_db, wrap_plain_in_span=True))
            body = "".join(inner_parts).strip()
            if href and body:
                parts.append(f'<a href="{html.escape(href, quote=True)}">{body}</a>')
            else:
                parts.append(body)
            continue

        # Runs
        if tag == "r":
            # Field chars inside run?
            fldChar = child.find("w:fldChar", namespaces=NS)
            if fldChar is not None:
                ftype = fldChar.get(f"{{{NS['w']}}}fldCharType")
                if ftype == "begin":
                    _flush_field()
                    in_field = True
                    instr_buf = []
                    in_result = False
                    result_buf = []
                elif ftype == "separate":
                    # start reading displayed result
                    in_result = True
                elif ftype == "end":
                    _flush_field()
                continue

            instrText = child.find("w:instrText", namespaces=NS)
            if instrText is not None and in_field and not in_result:
                instr_buf.append(instrText.text or "")
                continue

            # When we are in result part of a field, render runs into result buffer
            if in_field and in_result:
                result_buf.append(_run_to_inline_html(child, footnotes_ctx, footnotes_db, wrap_plain_in_span=True))
                continue

            # Normal run
            parts.append(_run_to_inline_html(child, footnotes_ctx, footnotes_db, wrap_plain_in_span=True))
            continue

        # Hyperlink elements can wrap runs
        if tag == "hyperlink":
            anchor = child.get(f"{{{NS['w']}}}anchor")
            rid = child.get(f"{{{NS['r']}}}id")
            href = None
            if rid and rid in rels:
                href = rels[rid]
            elif anchor:
                target_file = targets_map.get(anchor)
                a_id = sanitize_anchor_id(anchor)
                if (not target_file) or (target_file == current_filename):
                    href = f"#{a_id}"
                else:
                    href = f"{target_file}#{a_id}"

            inner_parts: List[str] = []
            for r in child.findall(".//w:r", namespaces=NS):
                inner_parts.append(_run_to_inline_html(r, footnotes_ctx, footnotes_db, wrap_plain_in_span=True))
            body = "".join(inner_parts).strip()
            if href and body:
                parts.append(f'<a href="{html.escape(href, quote=True)}">{body}</a>')
            else:
                parts.append(body)
            continue

        # Anything else: ignore (or could recurse)
        # Note: we do NOT auto-flush field here to allow fields spanning multiple children.

    # End paragraph: flush unfinished field if any
    _flush_field()

    # Join and clean up
    out = "".join(parts)
    # Word sometimes yields empty spans; keep output minimal
    return out
def _href_from_field_instr(instr: str, rels: Dict[str, str], targets_map: Dict[str, str], current_filename: str) -> Optional[str]:
    """Convert a Word field instruction string to an href when possible.

    Supports common cross-reference patterns:
      - REF Bookmark \h
      - PAGEREF Bookmark \h
      - HYPERLINK "http://..."
      - HYPERLINK \l Bookmark
    """
    if not instr:
        return None
    s = str(instr).strip()

    # HYPERLINK field
    if re.search(r"\bHYPERLINK\b", s, flags=re.I):
        # external link in quotes
        m = re.search(r'HYPERLINK\s+\"([^\"]+)\"', s, flags=re.I)
        if m:
            return m.group(1)
        # internal link: \l Bookmark (may be quoted or not)
        m = re.search(r"HYPERLINK\s+\\l\s+\"([^\"]+)\"", s, flags=re.I)
        if not m:
            m = re.search(r"HYPERLINK\s+\\l\s+([^\s\\]+)", s, flags=re.I)
        if m:
            bm = m.group(1)
            anchor_id = sanitize_anchor_id(bm)
            target_file = targets_map.get(bm)
            if target_file and target_file != current_filename:
                return f"{target_file}#{anchor_id}"
            return f"#{anchor_id}"
        return None

    # REF / PAGEREF (cross-reference to bookmark)
    m = re.search(r"\bREF\s+([^\s\\]+)", s, flags=re.I)
    if not m:
        m = re.search(r"\bPAGEREF\s+([^\s\\]+)", s, flags=re.I)
    if m:
        bm = m.group(1)
        anchor_id = sanitize_anchor_id(bm)
        target_file = targets_map.get(bm)
        if target_file and target_file != current_filename:
            return f"{target_file}#{anchor_id}"
        return f"#{anchor_id}"

    return None


def _extract_image_rIds_from_p(p) -> List[str]:
    # both wp:inline and wp:anchor contain a:blip with r:embed
    rids: List[str] = []
    blips = p.xpath(".//a:blip", namespaces=NS)
    for b in blips:
        rid = b.get(etree.QName(NS["r"], "embed"))
        if rid:
            rids.append(rid)
    return rids


def _extract_images_from_p_with_dims(p) -> List[Tuple[str, Optional[int], Optional[int]]]:
    """Return (rId, width_px, height_px) for images referenced in this paragraph.

    We read wp:extent (cx, cy) to preserve resized dimensions from the DOCX.
    """
    out: List[Tuple[str, Optional[int], Optional[int]]] = []
    drawings = p.xpath(".//w:drawing", namespaces=NS)
    for d in drawings:
        blip = d.find(".//a:blip", namespaces=NS)
        if blip is None:
            continue
        rid = blip.get(etree.QName(NS["r"], "embed"))
        if not rid:
            continue
        wpx = hpx = None
        extent = d.find(".//wp:extent", namespaces=NS)
        if extent is not None:
            cx = extent.get("cx")
            cy = extent.get("cy")
            if cx and cy:
                try:
                    wpx = _emu_to_px(int(cx))
                    hpx = _emu_to_px(int(cy))
                except Exception:
                    wpx = hpx = None
        out.append((rid, wpx, hpx))
    
    # Legacy VML images (common inside tables): <w:pict><v:shape ...><v:imagedata r:id="rIdX"/></v:shape></w:pict>
    # We also try to read width/height from the VML shape style (pt/px/in/cm/mm).
    def _vml_style_dim_px(style_str: Optional[str]) -> Tuple[Optional[int], Optional[int]]:
        if not style_str:
            return (None, None)
        s = str(style_str)

        def _len_to_px(token: str) -> Optional[int]:
            token = token.strip().lower()
            m = re.match(r"^([0-9]*\.?[0-9]+)\s*(px|pt|in|cm|mm)?$", token)
            if not m:
                return None
            v = float(m.group(1))
            unit = m.group(2) or "px"
            if unit == "px":
                return int(round(v))
            if unit == "pt":
                return int(round(v * 96.0 / 72.0))
            if unit == "in":
                return int(round(v * 96.0))
            if unit == "cm":
                return int(round(v * 96.0 / 2.54))
            if unit == "mm":
                return int(round(v * 96.0 / 25.4))
            return None

        wpx = hpx = None
        # style: "width:123pt;height:45pt" or "margin-left:...;width:..."
        for part in s.split(";"):
            if ":" not in part:
                continue
            k, v = part.split(":", 1)
            k = k.strip().lower()
            v = v.strip()
            if k == "width":
                wpx = _len_to_px(v) or wpx
            elif k == "height":
                hpx = _len_to_px(v) or hpx
        return (wpx, hpx)

    try:
        imagedatas = p.xpath(".//w:pict//v:imagedata", namespaces=NS)
    except Exception:
        imagedatas = []
    for imd in imagedatas:
        rid = imd.get(etree.QName(NS["r"], "id")) or imd.get(etree.QName(NS["r"], "embed"))
        if not rid:
            # sometimes o:relid
            rid = imd.get(etree.QName(NS.get("o", ""), "relid")) if NS.get("o") else None
        if not rid:
            continue
        # dims from nearest v:shape or v:rect style
        shape = imd.getparent()
        # climb a little to find a v:shape
        for _ in range(4):
            if shape is None:
                break
            if etree.QName(shape).localname in ("shape", "rect"):
                break
            shape = shape.getparent()
        wpx = hpx = None
        if shape is not None:
            wpx, hpx = _vml_style_dim_px(shape.get("style"))
        out.append((rid, wpx, hpx))

    if not out:
        for rid in _extract_image_rIds_from_p(p):
            out.append((rid, None, None))
    return out



# -------------------------
# List fallback by style name
# -------------------------

_LIST_STYLE_RE = re.compile(r"(liste|list)")


def infer_list_from_style(style_id: Optional[str]) -> Tuple[int, Optional[str]]:
    """Fallback when w:numPr is absent.

    Returns (list_level, list_type) where:
      - list_level: 0 means not a list; otherwise 1..9
      - list_type: 'unordered' or 'ordered'
    """
    if not style_id:
        return 0, None
    s = unidecode(style_id).lower().replace(" ", "")
    if not _LIST_STYLE_RE.search(s):
        return 0, None

    # Determine level from digits in style name (Liste3puces -> 3)
    lvl = 1
    m = re.search(r"(\d+)", s)
    if m:
        try:
            lvl = max(1, min(9, int(m.group(1))))
        except Exception:
            lvl = 1

    # Determine ordered/unordered
    if any(k in s for k in ("puce", "bullet", "bulle")):
        return lvl, "unordered"
    if any(k in s for k in ("num", "number", "numero", "décimal", "decimal")):
        return lvl, "ordered"

    # As a conservative fallback: treat 'liste' as unordered
    return lvl, "unordered"


def resolve_list_type_from_numbering(numbering: Numbering, numId: int, ilvl: int) -> Optional[str]:
    abs_id = numbering.numId_to_abs.get(str(numId))
    lvl_def = (numbering.abs_levels.get(abs_id or "", {}) or {}).get(int(ilvl))
    fmt = (lvl_def.num_fmt if lvl_def else "bullet")
    fmt_l = (fmt or "bullet").lower()
    return "unordered" if fmt_l == "bullet" else "ordered"


# -------------------------
# MkDocs files
# -------------------------

def generate_focus_assets(docs_dir: str, config: dict) -> None:
    js_dir = os.path.join(docs_dir, "javascripts")
    css_dir = os.path.join(docs_dir, "stylesheets")
    create_directory(js_dir)
    create_directory(css_dir)

    code_cfg = (config.get("code", {}) or {})
    rich_lh = code_cfg.get("rich_line_height", "theme")
    rich_ff = code_cfg.get("rich_font_family", "theme")
    rich_fs = code_cfg.get("rich_font_size", "theme")

    def _pick(v, theme_var, default_val):
        if v is None:
            return default_val
        s = str(v).strip()
        if s.lower() in ("theme", "default", ""):
            return theme_var
        return s

    rich_lh_css = _pick(rich_lh, "var(--md-code-line-height, 1.4)", "var(--md-code-line-height, 1.4)")
    rich_ff_css = _pick(rich_ff, "var(--md-code-font-family)", "var(--md-code-font-family)")
    rich_fs_css = _pick(rich_fs, "var(--md-code-font-size)", "var(--md-code-font-size)")

    with open(os.path.join(css_dir, "focus.css"), "w", encoding="utf-8") as f:
        f.write(
            "body.md-focus .md-sidebar--primary { display: none; } "
            "body.md-focus .md-sidebar--secondary { display: none; } "
            "body.md-focus .md-content { max-width: 95%; margin: 0 auto; } "
            ".focus-toggle-btn { cursor: pointer; margin-left: 0.5rem; } "
            ".odt-table img { max-width: 100%; height: auto; } "
            f".docx-code-rich pre, .docx-code-rich code, .docx-code-rich .docx-code-line {{ "
            f"font-family: {rich_ff_css}; font-size: {rich_fs_css}; line-height: {rich_lh_css}; "
            "}} "
            ".docx-code-rich pre { margin: 0.75em 0; } "
            ".docx-code-rich code { display: block; } "
            ".docx-code-rich .docx-code-line { display: block; } "
            ".docx-code-rich[data-linenums='true'] .docx-code-line::before { "
            "counter-increment: docxline; content: counter(docxline); display: inline-block; "
            "width: 3em; margin-right: 1em; opacity: 0.6; text-align: right; } "
            ".docx-code-rich[data-linenums='false'] .docx-code-line::before { content: ''; } "
            ".md-content ol { list-style-type: decimal; } "
            ".md-content ol ol { list-style-type: lower-alpha; } "
            ".md-content ol ol ol { list-style-type: lower-roman; } "
        )

    with open(os.path.join(js_dir, "focus.js"), "w", encoding="utf-8") as f:
        f.write(
            """document.addEventListener("DOMContentLoaded",function(){
      if(document.querySelector(".focus-toggle-btn")) return;
      var e=document.createElement("label");
      e.className="md-icon md-header__button focus-toggle-btn";
      e.title="Mode Focus";
      e.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5m12 7h-3v2h5v-5h-2v3M14 5v2h3v3h2V5h-5Z"></path></svg>';
      var t=document.querySelector(".md-header__inner");
      if(t) t.appendChild(e);
      e.addEventListener("click",function(){
    document.body.classList.toggle("md-focus");
      });
    });
    """
        )


def generate_mkdocs_yml(nav_structure: List[dict], config_data: dict) -> None:
    mk = config_data.get("mkdocs", {}) or {}
    use_dir = "true" if mk.get("use_directory_urls", False) else "false"

    out = ""
    out += f"site_name: \"{mk.get('site_name', 'My Site')}\"\n"
    out += f"site_url: \"{mk.get('site_url', '')}\"\n"
    out += f"site_description: \"{mk.get('site_description', '')}\"\n"
    out += f"site_author: \"{mk.get('site_author', '')}\"\n"
    out += f"use_directory_urls: {use_dir}\n"
    out += f"repo_url: \"{mk.get('repo_url', '')}\"\n"
    out += f"repo_name: \"{mk.get('repo_name', 'GitHub')}\"\n\n"

    theme_conf = mk.get("theme", {}) or {}
    out += "theme:\n"
    out += f"  name: {theme_conf.get('name', 'material')}\n"
    if "custom_dir" in theme_conf:
        out += f"  custom_dir: {theme_conf['custom_dir']}\n"
    if "features" in theme_conf:
        out += "  features:\n"
        for f in theme_conf["features"]:
            out += f"    - {f}\n"
    if "palette" in theme_conf:
        out += "  palette:\n"
        for pal in theme_conf["palette"]:
            out += "    - media: \"" + pal.get("media", "") + "\"\n"
            out += "      scheme: " + pal.get("scheme", "default") + "\n"
            out += "      primary: " + pal.get("primary", "teal") + "\n"
            out += "      accent: " + pal.get("accent", "purple") + "\n"
            if "toggle" in pal:
                out += "      toggle:\n"
                out += "        icon: " + pal["toggle"].get("icon", "") + "\n"
                out += "        name: " + pal["toggle"].get("name", "") + "\n"
    out += "\n"

    md_exts = mk.get("markdown_extensions", []) or []
    if md_exts:
        out += "markdown_extensions:\n"
        for ext in md_exts:
            if isinstance(ext, str):
                out += f"  - {ext}\n"
            elif isinstance(ext, dict):
                for k, v in ext.items():
                    out += f"  - {k}:\n"
                    if isinstance(v, dict):
                        for sub_k, sub_v in v.items():
                            val = str(sub_v).lower() if isinstance(sub_v, bool) else sub_v
                            out += f"      {sub_k}: {val}\n"
    out += "\n"
    out += "extra_javascript: [javascripts/focus.js]\n"
    out += "extra_css: [stylesheets/focus.css]\n\n"

    out += "nav:\n"
    for item in nav_structure:
        for k, v in item.items():
            safe_key = json.dumps(k, ensure_ascii=False)
            out += f"  - {safe_key}: {v}\n"

    extra_data = config_data.get("extra", {}) or {}
    if extra_data:
        out += "\nextra:\n"
        if "analytics" in extra_data:
            an = extra_data["analytics"]
            out += (
                "  analytics:\n"
                f"    provider: {an.get('provider', 'google')}\n"
                f"    property: {an.get('property', '')}\n"
            )

    with open("mkdocs.yml", "w", encoding="utf-8") as f:
        f.write(out)


# -------------------------
# Audit & reporting
# -------------------------
def write_audit(audit: dict, out_json: str = "audit.json", out_txt: str = "audit.txt") -> None:
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(audit, f, ensure_ascii=False, indent=2)

    # a small readable summary
    try:
        lines = []
        lines.append(f"Version: {VERSION}")
        lines.append(f"Paragraphs: {audit.get('counts', {}).get('paragraphs', 0)}")
        lines.append(f"Tables: {audit.get('counts', {}).get('tables', 0)}")
        lines.append(f"Images (blips): {audit.get('counts', {}).get('image_blips', 0)}")
        lines.append(f"Headings detected (raw): {audit.get('counts', {}).get('headings_raw', 0)}")
        lines.append(f"Min heading level detected (raw): {audit.get('heading', {}).get('min_level_raw')}")
        lines.append(f"Rebase offset applied: {audit.get('heading', {}).get('rebase_offset')}")
        lines.append("\nTop paragraph styles:")
        for s, n in (audit.get('top_styles', []) or [])[:20]:
            lines.append(f"  - {s}: {n}")
        lines.append("\nList paragraphs:")
        lp = audit.get('lists', {})
        lines.append(f"  - with numPr: {lp.get('with_numpr', 0)}")
        lines.append(f"  - by style fallback: {lp.get('by_style', 0)}")
        lines.append(f"  - not recognized: {lp.get('unrecognized', 0)}")
        with open(out_txt, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass


_LEVELS = {"error": 3, "warn": 2, "info": 1}


class ReportLogger:
    """Collects report entries and aggregates repetitive info (notably list-by-style fallbacks)."""

    def __init__(self, report_level: str = "info", verbose: bool = False) -> None:
        self.threshold = _LEVELS.get((report_level or "info").lower(), 1)
        self.verbose = bool(verbose)
        self.entries: List[Tuple[str, str]] = []  # (level, message)
        self.list_style_fallback_counts: Dict[Tuple[str, int, str], int] = {}
        self.block_ignored_counts: Dict[str, int] = {}

    def _add(self, level: str, msg: str) -> None:
        lvl = (level or "info").lower()
        if lvl not in _LEVELS:
            lvl = "info"
        self.entries.append((lvl, msg))

    def info(self, msg: str) -> None:
        if self.verbose:
            self._add("info", msg)

    def warn(self, msg: str) -> None:
        self._add("warn", msg)

    def error(self, msg: str) -> None:
        self._add("error", msg)

    def count_list_fallback(self, style_id: Optional[str], level: int, list_type: Optional[str]) -> None:
        s = style_id or "(no-style)"
        t = list_type or "unordered"
        key = (s, int(level or 1), t)
        self.list_style_fallback_counts[key] = self.list_style_fallback_counts.get(key, 0) + 1

    def count_ignored_block(self, tag: str) -> None:
        if not tag:
            return
        self.block_ignored_counts[tag] = self.block_ignored_counts.get(tag, 0) + 1

    def write(self, path: str = "report.txt") -> None:
        lines: List[str] = []

        if self.list_style_fallback_counts:
            lines.append("[SUMMARY] Listes détectées via fallback \"par style\" (agrégé)")
            for (style, lvl, t), n in sorted(
                self.list_style_fallback_counts.items(),
                key=lambda kv: (-kv[1], kv[0][0], kv[0][1], kv[0][2]),
            ):
                lines.append(f"  - {style} -> level={lvl} type={t}: {n}")

        if self.block_ignored_counts:
            lines.append("\n[SUMMARY] Blocs Word ignorés (agrégé)")
            for tag, n in sorted(self.block_ignored_counts.items(), key=lambda kv: (-kv[1], kv[0])):
                lines.append(f"  - <w:{tag}>: {n}")

        filtered = [
            (lvl, msg)
            for (lvl, msg) in self.entries
            if _LEVELS.get(lvl, 1) >= self.threshold
        ]
        if filtered:
            lines.append("\n[DETAIL]")
            for lvl, msg in filtered:
                lines.append(f"[{lvl.upper()}] {msg}")

        if not lines:
            lines = ["Aucune anomalie détectée."]

        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

# -------------------------
# Main conversion
# -------------------------

def convert_docx_to_site(docx_file: str, config_file: str, *, audit_only: bool = False, max_h1: Optional[int] = None,
                         start_h1: int = 1, report_out: str = "report.txt", report_level: str = "info",
                         verbose: bool = False, audit_out_json: str = "audit.json", audit_out_txt: str = "audit.txt") -> None:
    print(f"--- DOCX to MkDocs Converter {VERSION} ---")
    if not os.path.exists(docx_file):
        raise SystemExit(f"Erreur: fichier introuvable: {docx_file}")

    config = load_configuration(config_file)
    debug = bool(config.get("debug", False))
    logger = ReportLogger(report_level=report_level, verbose=verbose)

    with zipfile.ZipFile(docx_file, "r") as z:
        numbering = parse_numbering(z)
        rels = parse_relationships(z)
        footnotes_db = parse_footnotes_db(z)
        doc_xml = _zip_read_text(z, "word/document.xml")
        if not doc_xml:
            raise SystemExit("Erreur: word/document.xml introuvable dans le DOCX.")
        root = etree.fromstring(doc_xml)
        body = root.find(".//w:body", namespaces=NS)
        if body is None:
            raise SystemExit("Erreur: w:body introuvable dans le DOCX.")

        # ---------- PASS A: audit / detect heading rebasing ----------
        style_counts: Dict[str, int] = {}
        counts = {"paragraphs": 0, "tables": 0, "image_blips": 0, "headings_raw": 0}
        list_counts = {"with_numpr": 0, "by_style": 0, "unrecognized": 0}
        heading_levels_raw: List[int] = []

        for child in body:
            tag = etree.QName(child).localname
            if tag == "p":
                counts["paragraphs"] += 1
                style_id = _p_style(child) or "(no-style)"
                style_counts[style_id] = style_counts.get(style_id, 0) + 1
                # headings
                h1 = _heading_from_style(style_id if style_id != "(no-style)" else None)
                ol = _outline_level(child)
                lvl = None
                if h1 and ol:
                    lvl = min(h1, ol)
                else:
                    lvl = h1 or ol
                if lvl and lvl > 0:
                    counts["headings_raw"] += 1
                    heading_levels_raw.append(int(lvl))
                # lists
                numId, ilvl = _p_num_info(child)
                if numId is not None and ilvl is not None:
                    list_counts["with_numpr"] += 1
                else:
                    lvl2, t2 = infer_list_from_style(style_id if style_id != "(no-style)" else None)
                    if lvl2 > 0 and t2:
                        list_counts["by_style"] += 1
                    else:
                        # If it looks like a list paragraph (style contains list) but not recognized, count it.
                        s_clean = unidecode(style_id).lower()
                        if "liste" in s_clean or "list" in s_clean:
                            list_counts["unrecognized"] += 1

                # images
                counts["image_blips"] += len(_extract_image_rIds_from_p(child))
            elif tag == "tbl":
                # Audit pass counts tables unconditionally (no start_h1 gating here).
                counts["tables"] += 1

        min_level_raw = min(heading_levels_raw) if heading_levels_raw else None
        rebase_offset = 0
        if min_level_raw and min_level_raw > 1:
            rebase_offset = min_level_raw - 1

        audit = {
            "version": VERSION,
            "file": os.path.basename(docx_file),
            "counts": counts,
            "lists": list_counts,
            "heading": {
                "min_level_raw": min_level_raw,
                "rebase_offset": rebase_offset,
            },
            "top_styles": sorted(style_counts.items(), key=lambda kv: (-kv[1], kv[0]))[:50],
        }

        if audit_only:
            write_audit(audit, out_json=audit_out_json, out_txt=audit_out_txt)
            print(f"Audit terminé: {audit_out_json} / {audit_out_txt}")
            return

        
        # ---------- PASS 1: scan bookmarks -> target files ----------
        # We map each bookmark name to the markdown file that will contain it, so we can
        # generate correct cross-page links (same approach as the ODT converter V356).
        targets_map: Dict[str, str] = {}
        current_scan_file = "index.md"

        def _compute_heading_level(p_el) -> Optional[int]:
            sid = _p_style(p_el)
            h_by_style = _heading_from_style(sid) if sid else None
            h_by_outline = _outline_level(p_el)
            lvl0 = None
            if h_by_style and h_by_outline:
                lvl0 = min(h_by_style, h_by_outline)
            else:
                lvl0 = h_by_style or h_by_outline
            if not lvl0 or lvl0 <= 0:
                return None
            lvl = int(lvl0) - int(rebase_offset or 0)
            return lvl if lvl > 0 else None

        for blk in body:
            t = etree.QName(blk).localname
            if t == "p":
                lvl = _compute_heading_level(blk)
                if lvl == 1:
                    ttl = _p_plain_text(blk)
                    if ttl:
                        current_scan_file = generate_safe_filename(ttl)
                for bm in blk.xpath(".//w:bookmarkStart", namespaces=NS):
                    name = bm.get(etree.QName(NS["w"], "name"))
                    # Word uses special internal bookmarks like "_Toc..." or "_GoBack"
                    if name and not str(name).startswith("_"):
                        targets_map[str(name)] = current_scan_file
            elif t == "tbl":
                # bookmarks inside tables belong to the current_scan_file
                for bm in blk.xpath(".//w:bookmarkStart", namespaces=NS):
                    name = bm.get(etree.QName(NS["w"], "name"))
                    if name and not str(name).startswith("_"):
                        targets_map[str(name)] = current_scan_file

# ---------- Prepare output folders ----------
        if os.path.exists("docs"):
            shutil.rmtree("docs", ignore_errors=True)
        create_directory("docs")
        create_directory("docs/images")
        create_directory("overrides/partials/integrations")

        # Copy static files
        for f in config.get("files_to_copy", []) or []:
            if os.path.exists(f):
                try:
                    shutil.copy(f, os.path.join("docs", os.path.basename(f)))
                    print(f"Copié : {f}")
                except Exception as e:
                    logger.warn(f"Erreur copie {f}: {e}")

        # Assets + overrides
        generate_focus_assets("docs", config)
        with open("overrides/partials/footer.html", "w", encoding="utf-8") as f:
            f.write(config.get("footer", "<footer></footer>"))

        analytics_content = """{% if config.extra.analytics %}
  <script async src=\"https://www.googletagmanager.com/gtag/js?id={{ config.extra.analytics.property }}\"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    var siteName = \"{{ config.site_name | replace('\\"', '\\\\\"') }}\";
    gtag('config', '{{ config.extra.analytics.property }}', {
        'page_title': siteName
    });
  </script>
{% endif %}"""
        with open("overrides/partials/integrations/analytics.html", "w", encoding="utf-8") as f:
            f.write(analytics_content)
        with open("overrides/partials/analytics.html", "w", encoding="utf-8") as f:
            f.write(analytics_content)

        media_map = extract_media(z, "docs/images")

        # ---------- Output state ----------
        nav = [{"Accueil": "index.md"}]
        current_filename = "index.md"
        current_file = open(os.path.join("docs", current_filename), "w", encoding="utf-8")
        footnotes_ctx = init_footnotes_ctx()

        counters = [0] * 10
        found_any_h1 = False
        h1_pages_emitted = 0
        h1_seen = 0
        emitting = (start_h1 <= 1)

        code_buf: List[str] = []
        code_buf_html: List[Optional[str]] = []
        code_has_rich = False
        code_start_line = 1
        code_has_linenums = False

        list_seq: Dict[Tuple[str, int], int] = {}  # (numId, ilvl) -> current number for ordered lists

        prev_list_level = 0

        target_styles = [
            unidecode(s).lower().strip()
            for s in (config.get("document_title", {}).get("style_names", []) or [])
        ]

        def flush_code(indent_level: int = 0) -> None:
            nonlocal code_buf, code_buf_html, code_has_rich, code_start_line, code_has_linenums, emitting
            if not emitting:
                return
            if not code_buf:
                return
            full = "\n".join(code_buf)
            lang = detect_language(full, config.get("code", {}) or {})

            indent = "    " * max(0, indent_level)

            if code_has_rich and any(x is not None for x in code_buf_html):
                lines_html: List[str] = []
                for i, plain in enumerate(code_buf):
                    hl = code_buf_html[i] if i < len(code_buf_html) else None
                    lines_html.append(html.escape(plain) if hl is None else hl)
                block_html = render_rich_code_block(
                    lines_html, lang, start_line=code_start_line, show_linenums=code_has_linenums
                )
                block_html = "\n".join((indent + ln) if ln.strip() else ln for ln in block_html.splitlines())
                current_file.write("\n" + block_html + "\n\n")
            else:
                fence = get_fence(full)
                header = f"{indent}{fence}{lang}" + (f' linenums="{code_start_line}"' if code_has_linenums else "")
                current_file.write("\n" + header + "\n")
                for line in code_buf:
                    current_file.write(f"{indent}{line}\n")
                current_file.write(f"{indent}{fence}\n\n")

            code_buf = []
            code_buf_html = []
            code_has_rich = False
            code_start_line = 1
            code_has_linenums = False


        def write_paragraph(md: str, list_level: int, list_type: Optional[str], border_top: Optional[str] = None, border_bottom: Optional[str] = None) -> None:
            nonlocal prev_list_level, emitting
            if not emitting:
                return
            if prev_list_level > 0 and list_level == 0:
                current_file.write("\n")
            if prev_list_level == 0 and list_level > 0:
                current_file.write("\n")
            prev_list_level = list_level

            if not (md or "").strip() and not (border_top or border_bottom):
                return

            if list_level > 0 and list_type:
                indent = "    " * (list_level - 1)
                marker = "1. " if list_type == "ordered" else "- "
                current_file.write(f"{indent}{marker}{md}\n")
                return

            # Paragraph-level borders (top/bottom)
            if border_top or border_bottom:
                styles = []
                if border_top:
                    styles.append(f"border-top:{border_top}")
                if border_bottom:
                    styles.append(f"border-bottom:{border_bottom}")
                styles.append("padding:0.35em 0")
                styles.append("margin:0.75em 0")
                current_file.write(f"<div style=\"{' ; '.join(styles)}\">{md}</div>\n\n")
            else:
                current_file.write(md + "\n\n")

        def new_page_for_h1(title_plain: str, title_md: str, num_str: str) -> None:
            nonlocal current_file, current_filename, h1_pages_emitted, footnotes_ctx
            write_footnotes(current_file, footnotes_ctx)
            current_file.close()
            footnotes_ctx = init_footnotes_ctx()
            fname = generate_safe_filename(title_plain)
            current_filename = fname
            current_file = open(os.path.join("docs", fname), "w", encoding="utf-8")
            current_file.write(f"# {num_str}. {title_md}\n\n")
            nav.append({f"{num_str}. {title_plain}": fname})
            h1_pages_emitted += 1

        # ---------- PASS B: generate ----------
        for child in body:
            tag = etree.QName(child).localname

            if tag == "p":
                style_id = _p_style(child)
                style_id_norm = unidecode(style_id).lower().strip() if style_id else ""

                # Determine heading level (raw then rebased)
                lvl_style = _heading_from_style(style_id)
                lvl_outline = _outline_level(child)
                heading_lvl = None
                if lvl_style and lvl_outline:
                    heading_lvl = min(lvl_style, lvl_outline)
                else:
                    heading_lvl = lvl_style or lvl_outline

                if heading_lvl and heading_lvl > 0 and rebase_offset:
                    heading_lvl = max(1, int(heading_lvl) - int(rebase_offset))

                # Determine list info
                numId, ilvl = _p_num_info(child)
                list_level = 0
                list_type: Optional[str] = None
                list_mode = None
                if numId is not None and ilvl is not None:
                    list_level = int(ilvl) + 1
                    list_type = resolve_list_type_from_numbering(numbering, int(numId), int(ilvl))
                    list_mode = "numPr"
                else:
                    lvl2, t2 = infer_list_from_style(style_id)
                    if lvl2 > 0 and t2:
                        list_level, list_type = lvl2, t2
                        list_mode = "style"

                # Debug (optional)
                if debug and not found_any_h1:
                    preview = (paragraph_to_inline_html(child, rels, targets_map, current_filename, footnotes_ctx, footnotes_db) or "")[:80]
                    print(
                        f"[DEBUG PRE-H1] style={style_id} heading={heading_lvl} rebase={rebase_offset} "
                        f"numId={numId} ilvl={ilvl} list={list_mode}:{list_level}/{list_type} txt='{preview}...'"
                    )

                # Document title (styled)
                if style_id_norm and style_id_norm in target_styles:
                    txt = paragraph_to_inline_html(child, rels, targets_map, current_filename, footnotes_ctx, footnotes_db)
                    css = (config.get("document_title", {}) or {}).get("css", "")
                    if emitting:
                        current_file.write(f'<p style="{css}">{txt}</p>\n\n')
                    continue

                # Headings
                if heading_lvl and heading_lvl > 0:
                    flush_code(0)
                    title_plain = etree.tostring(child, method="text", encoding="unicode").strip()
                    title_plain = re.sub(r"\s+", " ", title_plain)
                    title_md = paragraph_to_inline_html(child, rels, targets_map, current_filename, footnotes_ctx, footnotes_db) or escape_markdown_text(title_plain)

                    # counters
                    counters[int(heading_lvl) - 1] += 1
                    for i in range(int(heading_lvl), 10):
                        counters[i] = 0
                    # Build heading numbering string (e.g. 1, 1.2, 1.2.3)
                    if int(heading_lvl) > 1:
                        num_str = ".".join(str(counters[i]) for i in range(int(heading_lvl)))
                    else:
                        num_str = str(counters[0])

                    if int(heading_lvl) == 1:
                        found_any_h1 = True
                        h1_seen += 1

                        # Skip everything until we reach the requested H1 (start_h1),
                        # but keep counters so numbering remains consistent.
                        if h1_seen < start_h1:
                            code_buf = []
                            prev_list_level = 0
                            continue

                        if not emitting:
                            emitting = True

                        # Stop if max-h1 exceeded (before creating the page)
                        if max_h1 is not None and h1_pages_emitted >= max_h1:
                            logger.warn(
                                f"Arrêt anticipé (--start-h1={start_h1}, --max-h1={max_h1}) "
                                f"après {h1_pages_emitted} pages H1 générées."
                            )
                            break

                        new_page_for_h1(title_plain, title_md, num_str)

                    else:
                        current_file.write(f"{'#' * int(heading_lvl)} {num_str}. {title_md}\n\n")
                    continue

                # Code paragraphs
                if emitting and is_code_paragraph_by_style(style_id, config.get("code", {}) or {}):
                    this_is_rich = paragraph_has_rich_code_formatting(child)

                    numbered = False
                    current_num = None

                    if list_mode == "numPr" and list_type == "ordered" and numId is not None and ilvl is not None:
                        key = (str(numId), int(ilvl))
                        if key not in list_seq:
                            abs_id = numbering.numId_to_abs.get(str(numId), "")
                            ld = numbering.abs_levels.get(abs_id, {}).get(int(ilvl))
                            list_seq[key] = int(ld.start) if ld else 1
                        current_num = list_seq.get(key, 1)
                        numbered = True
                    else:
                        s_l = (unidecode(style_id).lower() if style_id else "")
                        if "num" in s_l or "numero" in s_l:
                            numbered = True
                            current_num = 1

                    if not code_buf:
                        code_start_line = int(current_num or 1)
                        code_has_linenums = bool(numbered)
                        code_has_rich = False
                        code_buf_html = []

                    line_txt = _p_text_preserve(child)
                    code_buf.append(line_txt)

                    if this_is_rich:
                        code_has_rich = True
                        code_buf_html.append(runs_to_rich_code_html_line(child))
                    else:
                        code_buf_html.append(None)

                    if list_mode == "numPr" and list_type == "ordered" and numId is not None and ilvl is not None:
                        key = (str(numId), int(ilvl))
                        if key in list_seq:
                            list_seq[key] += 1
                    continue

                # Flush code when leaving code block


                if code_buf:
                    flush_code(0)

                # Normal paragraph / list item
                md_text = paragraph_to_inline_html(child, rels, targets_map, current_filename, footnotes_ctx, footnotes_db)

                border_top, border_bottom = _p_borders_css(child)


                # Images after paragraph
                img_refs = _extract_images_from_p_with_dims(child)
                imgs: List[str] = []
                for rid, wpx, hpx in img_refs:
                    target = rels.get(rid)
                    if not target:
                        logger.warn(f"Image rId introuvable dans rels: {rid}")
                        continue
                    if not target.startswith("word/"):
                        target_full = "word/" + target.lstrip("./")
                    else:
                        target_full = target
                    target_full = target_full.replace("\\", "/")
                    src = media_map.get(target_full)
                    if not src:
                        logger.warn(f"Cible image non extraite: {target_full} (rId={rid})")
                        continue
                    style = "max-width:100%;height:auto;"
                    if wpx and hpx:
                        style = f"width:{wpx}px;height:{hpx}px;"
                    elif wpx and not hpx:
                        style = f"width:{wpx}px;height:auto;"
                    elif hpx and not wpx:
                        style = f"height:{hpx}px;width:auto;"
                    imgs.append(f'<img src="{src}" style="{style}" alt="Image" />')

                # Report list fallback usage (useful on large docs)
                if list_mode == "style":
                    logger.count_list_fallback(style_id, list_level, list_type)
                    logger.info(f"Liste par style: style='{style_id}' -> level={list_level} type={list_type}")

                if imgs:
                    if md_text.strip():
                        write_paragraph(md_text, list_level, list_type, border_top, border_bottom)
                    for im in imgs:
                        write_paragraph(im, 0, None)
                else:
                    write_paragraph(md_text, list_level, list_type, border_top, border_bottom)

            elif tag == "tbl":
                if not emitting:
                    continue
                flush_code(0)
                rows = child.xpath(".//w:tr", namespaces=NS)
                html_lines = [
                    '<table class="odt-table" style="border-collapse: collapse; width: 100%; margin-bottom: 1em;">'
                ]
                for tr in rows:
                    html_lines.append("<tr>")
                    cells = tr.xpath("./w:tc", namespaces=NS)
                    for tc in cells:
                                                # Extract cell content: text + images (including VML) while preserving image resizing when available
                        html_lines.append(
                            '<td style="border: 1px solid #ddd; padding: 8px; vertical-align: top;">'
                        )
                        cell_parts: List[str] = []
                                                # Iterate paragraphs in cell in document order, including code blocks
                        code_cfg = config.get("code", {}) or {}
                        cell_code_buf: List[str] = []
                        cell_code_buf_html: List[Optional[str]] = []
                        cell_code_start = 1
                        cell_code_linenums = False
                        cell_code_rich = False

                        def _flush_cell_code():
                            nonlocal cell_code_buf, cell_code_buf_html, cell_code_start, cell_code_linenums, cell_code_rich
                            if not cell_code_buf:
                                return
                            full = "\n".join(cell_code_buf)
                            lang = detect_language(full, code_cfg)
                            lines_html: List[str] = []
                            if cell_code_rich and any(x is not None for x in cell_code_buf_html):
                                for i, plain in enumerate(cell_code_buf):
                                    hl = cell_code_buf_html[i] if i < len(cell_code_buf_html) else None
                                    lines_html.append(html.escape(plain) if hl is None else hl)
                            else:
                                lines_html = [html.escape(x) for x in cell_code_buf]
                            cell_parts.append(render_rich_code_block(lines_html, lang, start_line=cell_code_start, show_linenums=cell_code_linenums))
                            cell_code_buf = []
                            cell_code_buf_html = []
                            cell_code_start = 1
                            cell_code_linenums = False
                            cell_code_rich = False

                        # List handling inside table cells (preserve nested lists)
                        cell_list_stack: List[Dict[str, object]] = []

                        def _close_cell_lists(target_level: int = 0) -> None:
                            nonlocal cell_list_stack, cell_parts
                            while len(cell_list_stack) > target_level:
                                top = cell_list_stack.pop()
                                if top.get("li_open"):
                                    cell_parts.append("</li>")
                                cell_parts.append(f"</{top.get('tag')}>")

                        def _start_cell_list_item(level: int, list_type: Optional[str]) -> None:
                            nonlocal cell_list_stack, cell_parts
                            tag = "ol" if (list_type == "ordered") else "ul"
                            if len(cell_list_stack) > level:
                                _close_cell_lists(level)
                            while len(cell_list_stack) < level:
                                cell_parts.append(f"<{tag}>")
                                cell_list_stack.append({"tag": tag, "li_open": False})
                            if not cell_list_stack:
                                return
                            if cell_list_stack[-1].get("li_open"):
                                cell_parts.append("</li><li>")
                            else:
                                cell_parts.append("<li>")
                                cell_list_stack[-1]["li_open"] = True

                        for p_in in tc.xpath("./w:p", namespaces=NS):
                            style_p = _p_style(p_in)
                            style_p_l = unidecode(style_p).lower() if style_p else ""
                            is_code_p = is_code_paragraph_by_style(style_p, code_cfg)

                            if is_code_p:
                                # Determine if this code block is "numbered" (by style name hint or ordered list numPr)
                                numId_c, ilvl_c = _p_num_info(p_in)
                                list_mode_c = None
                                list_type_c = None
                                if numId_c is not None and ilvl_c is not None:
                                    list_type_c = resolve_list_type_from_numbering(numbering, int(numId_c), int(ilvl_c))
                                    list_mode_c = "numPr"
                                numbered = False
                                if (list_mode_c == "numPr" and list_type_c == "ordered"):
                                    numbered = True
                                if ("num" in style_p_l or "numero" in style_p_l):
                                    numbered = True

                                if not cell_code_buf:
                                    cell_code_start = 1
                                    cell_code_linenums = bool(numbered)
                                    cell_code_rich = False
                                    cell_code_buf_html = []

                                line_txt = _p_text_preserve(p_in)
                                cell_code_buf.append(line_txt)
                                rich = paragraph_has_rich_code_formatting(p_in)
                                if rich:
                                    cell_code_rich = True
                                    cell_code_buf_html.append(runs_to_rich_code_html_line(p_in))
                                else:
                                    cell_code_buf_html.append(None)
                                continue

                            # not code
                            _flush_cell_code()

                            # Determine list level/type for this paragraph (inside table)
                            numId_l, ilvl_l = _p_num_info(p_in)
                            list_level_l = 0
                            list_type_l: Optional[str] = None
                            if numId_l is not None and ilvl_l is not None:
                                list_level_l = int(ilvl_l) + 1
                                list_type_l = resolve_list_type_from_numbering(numbering, int(numId_l), int(ilvl_l))
                            else:
                                lvl2, t2 = infer_list_from_style(style_p)
                                if lvl2 > 0:
                                    list_level_l = lvl2
                                    list_type_l = t2 or "unordered"

                            t = paragraph_to_inline_html(p_in, rels, targets_map, current_filename, footnotes_ctx, footnotes_db).strip()

                            if list_level_l > 0:
                                _start_cell_list_item(list_level_l, list_type_l)
                                if t:
                                    cell_parts.append(t)
                            else:
                                _close_cell_lists(0)
                                if t:
                                    cell_parts.append(f"<p style='margin:0;'>{t}</p>")
                            for rid, wpx, hpx in _extract_images_from_p_with_dims(p_in):
                                target = rels.get(rid)
                                if not target:
                                    logger.warn(f"Image rId introuvable dans rels (table): {rid}")
                                    continue
                                if not target.startswith("word/"):
                                    target_full = "word/" + target.lstrip("./")
                                else:
                                    target_full = target
                                target_full = target_full.replace("\\", "/")
                                src_img = media_map.get(target_full)
                                if not src_img:
                                    logger.warn(f"Cible image non extraite (table): {target_full} (rId={rid})")
                                    continue
                                style = "max-width:100%;height:auto;"
                                if wpx and hpx:
                                    style = f"width:{wpx}px;height:{hpx}px;"
                                elif wpx and not hpx:
                                    style = f"width:{wpx}px;height:auto;"
                                elif hpx and not wpx:
                                    style = f"height:{hpx}px;width:auto;"
                                cell_parts.append(f'<img src="{src_img}" style="{style}" alt="Image" />')
                        _flush_cell_code()
                        _close_cell_lists(0)
                        if not cell_parts:
                            cell_parts.append("&nbsp;")
                        html_lines.append("".join(cell_parts))
                        html_lines.append("</td>")
                    html_lines.append("</tr>")
                html_lines.append("</table>")
                current_file.write("\n".join(html_lines) + "\n\n")
            else:
                # unsupported block types
                logger.count_ignored_block(tag)
                logger.info(f"Bloc ignoré: <w:{tag}>")

        # Final flush
        if code_buf:
            flush_code(0)
        write_footnotes(current_file, footnotes_ctx)
        current_file.close()

    # If no H1 at all, warn (and suggest checking styles)
    if not audit.get("heading", {}).get("min_level_raw"):
        logger.warn("Aucun titre détecté (Heading/Titre/outlineLvl). Vérifier les styles Word.")

    # Persist audit + report
    write_audit(audit, out_json=audit_out_json, out_txt=audit_out_txt)
    logger.write(report_out)

    generate_mkdocs_yml(nav, config)
    print(f"Terminé. ({audit_out_json}, {audit_out_txt}, {report_out} générés)")


def main(argv: List[str]) -> int:
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("docx", help="Fichier .docx à convertir")
    ap.add_argument("config", help="config.py ou config.json")
    ap.add_argument("--audit", action="store_true", help="Analyse uniquement (ne génère pas le site)")
    ap.add_argument("--max-h1", type=int, default=None, help="Limiter la génération aux N premiers titres H1")
    ap.add_argument("--start-h1", type=int, default=1, help="Commencer la génération à partir du K-ième titre H1 (1=depuis le début)")
    ap.add_argument("--report-out", default="report.txt", help="Chemin du rapport (défaut: report.txt)")
    ap.add_argument("--report-level", default="info", choices=["info", "warn", "error"], help="Niveau de détail du rapport")
    ap.add_argument("--verbose", action="store_true", help="Inclure les lignes INFO détaillées dans le report")
    ap.add_argument("--audit-out-json", default="audit.json", help="Chemin de sortie audit.json")
    ap.add_argument("--audit-out-txt", default="audit.txt", help="Chemin de sortie audit.txt")
    args = ap.parse_args(argv)

    convert_docx_to_site(
        args.docx,
        args.config,
        audit_only=args.audit,
        max_h1=args.max_h1,
        start_h1=max(1, int(args.start_h1)),
        report_out=args.report_out,
        report_level=args.report_level,
        verbose=args.verbose,
        audit_out_json=args.audit_out_json,
        audit_out_txt=args.audit_out_txt,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))